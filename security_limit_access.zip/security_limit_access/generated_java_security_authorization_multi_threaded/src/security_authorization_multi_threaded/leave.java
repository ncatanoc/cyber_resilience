package security_authorization_multi_threaded; 

import eventb_prelude.*;
import Util.Utilities;

public class leave extends Thread{
	/*@ spec_public */ private authorization machine; // reference to the machine 

	/*@ public normal_behavior
		requires true;
		assignable \everything;
		ensures this.machine == m; */
	public leave(authorization m) {
		this.machine = m;
	}

	/*@ public normal_behavior
		requires true;
 		assignable \nothing;
		ensures \result <==> (machine.get_subjects().has(u) &&  newperm.domain().equals(machine.get_subjects()) && newperm.range().isSubset(BRelation.cross(machine.get_resources(),BRelation.cross(machine.get_subjects(),INT.instance))) && newperm.isaFunction() && BRelation.cross(machine.get_subjects(),BRelation.cross(machine.get_resources(),BRelation.cross(machine.get_subjects(),INT.instance))).has(newperm) &&  (\forall Integer us;((machine.get_subjects().has(us)) ==> (machine.get_perm().apply(us).domain().equals(newperm.apply(us).domain())))) &&  (\forall Integer us;  (\forall Integer d;((machine.get_subjects().has(us) && !us.equals(u) && machine.get_perm().apply(us).domain().has(d)) ==> (newperm.apply(us).apply(d).equals(machine.get_perm().apply(us).apply(d).domainSubtraction(new BSet<Integer>(u)))))))); */
	public /*@ pure */ boolean guard_leave( BRelation<Integer,BRelation<Integer,BRelation<Integer,Integer>>> newperm, Integer u) {
		return (machine.get_subjects().has(u) &&  newperm.domain().equals(machine.get_subjects()) && newperm.range().isSubset(BRelation.cross(machine.get_resources(),BRelation.cross(machine.get_subjects(),INT.instance))) && newperm.isaFunction() && BRelation.cross(machine.get_subjects(),BRelation.cross(machine.get_resources(),BRelation.cross(machine.get_subjects(),INT.instance))).has(newperm) && true && true);
	}

	/*@ public normal_behavior
		requires guard_leave(newperm,u);
		assignable machine.perm, machine.subjects, machine.resources;
		ensures guard_leave(newperm,u) &&  machine.get_perm().equals(\old(newperm.domainSubtraction(new BSet<Integer>(u)))) &&  machine.get_subjects().equals(\old(machine.get_subjects().difference(new BSet<Integer>(u)))) &&  machine.get_resources().equals(\old(machine.get_resources().difference(machine.get_perm().apply(u).domain()))); 
	 also
		requires !guard_leave(newperm,u);
		assignable \nothing;
		ensures true; */
	public void run_leave( BRelation<Integer,BRelation<Integer,BRelation<Integer,Integer>>> newperm, Integer u){
		if(guard_leave(newperm,u)) {
			BRelation<Integer,BRelation<Integer,BRelation<Integer,Integer>>> perm_tmp = machine.get_perm();
			BSet<Integer> subjects_tmp = machine.get_subjects();
			BSet<Integer> resources_tmp = machine.get_resources();

			machine.set_perm(newperm.domainSubtraction(new BSet<Integer>(u)));
			machine.set_subjects(subjects_tmp.difference(new BSet<Integer>(u)));
			machine.set_resources(resources_tmp.difference(perm_tmp.apply(u).domain()));

			System.out.println("leave executed newperm: " + newperm + " u: " + u + " ");
		}
	}

	public void run() {
		while(true) {
			BRelation<Integer,BRelation<Integer,BRelation<Integer,Integer>>> newperm = null; //not supported yet
			Integer u = Utilities.someVal(new BSet<Integer>((new Enumerated(1,Utilities.max_integer))));
			machine.lock.lock(); // start of critical section
			run_leave(newperm,u);
			machine.lock.unlock(); // end of critical section
		}
	}
}
