package security_authorization_multi_threaded; 

import eventb_prelude.*;
import Util.Utilities;

public class add_subject extends Thread{
	/*@ spec_public */ private authorization machine; // reference to the machine 

	/*@ public normal_behavior
		requires true;
		assignable \everything;
		ensures this.machine == m; */
	public add_subject(authorization m) {
		this.machine = m;
	}

	/*@ public normal_behavior
		requires true;
 		assignable \nothing;
		ensures \result <==> (machine.SUBJECTS.difference(machine.get_subjects()).has(u) && machine.RESOURCES.difference(machine.get_resources()).has(d)); */
	public /*@ pure */ boolean guard_add_subject( Integer d, Integer u) {
		return (machine.SUBJECTS.difference(machine.get_subjects()).has(u) && machine.RESOURCES.difference(machine.get_resources()).has(d));
	}

	/*@ public normal_behavior
		requires guard_add_subject(d,u);
		assignable machine.resources, machine.subjects, machine.perm;
		ensures guard_add_subject(d,u) &&  machine.get_resources().equals(\old((machine.get_resources().union(new BSet<Integer>(d))))) &&  machine.get_subjects().equals(\old((machine.get_subjects().union(new BSet<Integer>(u))))) &&  machine.get_perm().equals(\old((machine.get_perm().union(new BRelation<Integer,BRelation<Integer,BSet<Integer>>>(new Pair<Integer,BRelation<Integer,BSet<Integer>>>(u,new BRelation<Integer,BSet<Integer>>(new Pair<Integer,BSet<Integer>>(d,BRelation.cross(new BSet<Integer>(u),INT.instance))))))))); 
	 also
		requires !guard_add_subject(d,u);
		assignable \nothing;
		ensures true; */
	public void run_add_subject( Integer d, Integer u){
		if(guard_add_subject(d,u)) {
			BSet<Integer> resources_tmp = machine.get_resources();
			BSet<Integer> subjects_tmp = machine.get_subjects();
			BRelation<Integer,BRelation<Integer,BRelation<Integer,Integer>>> perm_tmp = machine.get_perm();

			machine.set_resources((resources_tmp.union(new BSet<Integer>(d))));
			machine.set_subjects((subjects_tmp.union(new BSet<Integer>(u))));
			machine.set_perm((perm_tmp.union(new BRelation<Integer,BRelation<Integer,BSet<Integer>>>(new Pair<Integer,BRelation<Integer,BSet<Integer>>>(u,new BRelation<Integer,BSet<Integer>>(new Pair<Integer,BSet<Integer>>(d,BRelation.cross(new BSet<Integer>(u),INT.instance))))))));

			System.out.println("add_subject executed d: " + d + " u: " + u + " ");
		}
	}

	public void run() {
		while(true) {
			Integer d = Utilities.someVal(new BSet<Integer>((new Enumerated(1,Utilities.max_integer))));
			Integer u = Utilities.someVal(new BSet<Integer>((new Enumerated(1,Utilities.max_integer))));
			machine.lock.lock(); // start of critical section
			run_add_subject(d,u);
			machine.lock.unlock(); // end of critical section
		}
	}
}
