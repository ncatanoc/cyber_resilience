package security_authorization_multi_threaded; 

import eventb_prelude.*;
import Util.Utilities;

public class grant_permission extends Thread{
	/*@ spec_public */ private authorization machine; // reference to the machine 

	/*@ public normal_behavior
		requires true;
		assignable \everything;
		ensures this.machine == m; */
	public grant_permission(authorization m) {
		this.machine = m;
	}

	/*@ public normal_behavior
		requires true;
 		assignable \nothing;
		ensures \result <==> (machine.get_subjects().has(u) && machine.get_perm().apply(u).domain().has(d) && machine.get_subjects().difference(new BSet<Integer>(u)).has(u1) && INT.instance.has(per) && !machine.get_perm().apply(u).apply(d).has(new Pair<Integer,Integer>(u1,per))); */
	public /*@ pure */ boolean guard_grant_permission( Integer d, Integer per, Integer u, Integer u1) {
		return (machine.get_subjects().has(u) && machine.get_perm().apply(u).domain().has(d) && machine.get_subjects().difference(new BSet<Integer>(u)).has(u1) && INT.instance.has(per) && !machine.get_perm().apply(u).apply(d).has(new Pair<Integer,Integer>(u1,per)));
	}

	/*@ public normal_behavior
		requires guard_grant_permission(d,per,u,u1);
		assignable machine.perm;
		ensures guard_grant_permission(d,per,u,u1) &&  machine.get_perm().equals(\old((machine.get_perm().override(new BRelation<Integer,BRelation<Integer,BRelation<Integer,Integer>>>(new Pair<Integer,BRelation<Integer,BRelation<Integer,Integer>>>(u,(machine.get_perm().apply(u).override(new BRelation<Integer,BRelation<Integer,Integer>>(new Pair<Integer,BRelation<Integer,Integer>>(d,(machine.get_perm().apply(u).apply(d).union(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(u1,per)))))))))))))); 
	 also
		requires !guard_grant_permission(d,per,u,u1);
		assignable \nothing;
		ensures true; */
	public void run_grant_permission( Integer d, Integer per, Integer u, Integer u1){
		if(guard_grant_permission(d,per,u,u1)) {
			BRelation<Integer,BRelation<Integer,BRelation<Integer,Integer>>> perm_tmp = machine.get_perm();

			machine.set_perm((perm_tmp.override(new BRelation<Integer,BRelation<Integer,BRelation<Integer,Integer>>>(new Pair<Integer,BRelation<Integer,BRelation<Integer,Integer>>>(u,(perm_tmp.apply(u).override(new BRelation<Integer,BRelation<Integer,Integer>>(new Pair<Integer,BRelation<Integer,Integer>>(d,(perm_tmp.apply(u).apply(d).union(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(u1,per)))))))))))));

			System.out.println("grant_permission executed d: " + d + " per: " + per + " u: " + u + " u1: " + u1 + " ");
		}
	}

	public void run() {
		while(true) {
			Integer d = Utilities.someVal(new BSet<Integer>((new Enumerated(1,Utilities.max_integer))));
			Integer per = Utilities.someVal(new BSet<Integer>((new Enumerated(1,Utilities.max_integer))));
			Integer u = Utilities.someVal(new BSet<Integer>((new Enumerated(1,Utilities.max_integer))));
			Integer u1 = Utilities.someVal(new BSet<Integer>((new Enumerated(1,Utilities.max_integer))));
			machine.lock.lock(); // start of critical section
			run_grant_permission(d,per,u,u1);
			machine.lock.unlock(); // end of critical section
		}
	}
}
