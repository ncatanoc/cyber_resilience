package security_authorization_multi_threaded; 

import eventb_prelude.*;
import Util.Utilities;

public class add_resource extends Thread{
	/*@ spec_public */ private authorization machine; // reference to the machine 

	/*@ public normal_behavior
		requires true;
		assignable \everything;
		ensures this.machine == m; */
	public add_resource(authorization m) {
		this.machine = m;
	}

	/*@ public normal_behavior
		requires true;
 		assignable \nothing;
		ensures \result <==> (machine.get_subjects().has(u) && machine.RESOURCES.difference(machine.get_resources()).has(d)); */
	public /*@ pure */ boolean guard_add_resource( Integer d, Integer u) {
		return (machine.get_subjects().has(u) && machine.RESOURCES.difference(machine.get_resources()).has(d));
	}

	/*@ public normal_behavior
		requires guard_add_resource(d,u);
		assignable machine.perm, machine.resources;
		ensures guard_add_resource(d,u) &&  machine.get_perm().equals(\old((machine.get_perm().override(new BRelation<Integer,BRelation<Integer,BRelation<Integer,Integer>>>(new Pair<Integer,BRelation<Integer,BRelation<Integer,Integer>>>(u,(machine.get_perm().apply(u).union(new BRelation<Integer,BSet<Integer>>(new Pair<Integer,BSet<Integer>>(d,BRelation.cross(new BSet<Integer>(u),INT.instance))))))))))) &&  machine.get_resources().equals(\old((machine.get_resources().union(new BSet<Integer>(d))))); 
	 also
		requires !guard_add_resource(d,u);
		assignable \nothing;
		ensures true; */
	public void run_add_resource( Integer d, Integer u){
		if(guard_add_resource(d,u)) {
			BRelation<Integer,BRelation<Integer,BRelation<Integer,Integer>>> perm_tmp = machine.get_perm();
			BSet<Integer> resources_tmp = machine.get_resources();

			machine.set_perm((perm_tmp.override(new BRelation<Integer,BRelation<Integer,BRelation<Integer,Integer>>>(new Pair<Integer,BRelation<Integer,BRelation<Integer,Integer>>>(u,(perm_tmp.apply(u).union(new BRelation<Integer,BSet<Integer>>(new Pair<Integer,BSet<Integer>>(d,BRelation.cross(new BSet<Integer>(u),INT.instance))))))))));
			machine.set_resources((resources_tmp.union(new BSet<Integer>(d))));

			System.out.println("add_resource executed d: " + d + " u: " + u + " ");
		}
	}

	public void run() {
		while(true) {
			Integer d = Utilities.someVal(new BSet<Integer>((new Enumerated(1,Utilities.max_integer))));
			Integer u = Utilities.someVal(new BSet<Integer>((new Enumerated(1,Utilities.max_integer))));
			machine.lock.lock(); // start of critical section
			run_add_resource(d,u);
			machine.lock.unlock(); // end of critical section
		}
	}
}
