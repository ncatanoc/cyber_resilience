package security_authentication; 

import eventb_prelude.*;
import Util.Utilities;

public class add_hash_key extends Thread{
	/*@ spec_public */ private authentication machine; // reference to the machine 

	/*@ public normal_behavior
		requires true;
		assignable \everything;
		ensures this.machine == m; */
	public add_hash_key(authentication m) {
		this.machine = m;
	}

	/*@ public normal_behavior
		requires true;
 		assignable \nothing;
		ensures \result <==> (machine.KEYS.difference(machine.get_keys()).has(k) && machine.HASHES.has(h)); */
	public /*@ pure */ boolean guard_add_hash_key( Integer h, Integer k) {		
		return (machine.KEYS.difference(machine.get_keys()).has(k) && machine.HASHES.has(h));
	}

	/*@ public normal_behavior
		requires guard_add_hash_key(h,k);
		assignable machine.keys, machine.hashes, machine.hash;
		ensures guard_add_hash_key(h,k) &&  machine.get_keys().equals(\old((machine.get_keys().union(new BSet<Integer>(k))))) &&  machine.get_hashes().equals(\old((machine.get_hashes().union(new BSet<Integer>(h))))) &&  machine.get_hash().equals(\old((machine.get_hash().override(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(k,h)))))); 
	 also
		requires !guard_add_hash_key(h,k);
		assignable \nothing;
		ensures true; */
	public void run_add_hash_key( Integer h, Integer k){
		if(guard_add_hash_key(h,k)) {
			BSet<Integer> keys_tmp = machine.get_keys();
			BSet<Integer> hashes_tmp = machine.get_hashes();
			BRelation<Integer,Integer> hash_tmp = machine.get_hash();

			machine.set_keys((keys_tmp.union(new BSet<Integer>(k))));
			machine.set_hashes((hashes_tmp.union(new BSet<Integer>(h))));
			machine.set_hash((hash_tmp.override(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(k,h)))));

			System.out.println("add_hash_key executed h: " + h + " k: " + k + " ");
		}
	}

	public void run() {
		while(true) {
			Integer h = Utilities.someVal(new BSet<Integer>((new Enumerated(1,Utilities.max_integer))));
			Integer k = Utilities.someVal(new BSet<Integer>((new Enumerated(1,Utilities.max_integer))));
			machine.lock.lock(); // start of critical section
			run_add_hash_key(h,k);
			machine.lock.unlock(); // end of critical section
		}
	}
}
