package security_authentication;

import eventb_prelude.*;
import Util.*;
//@ model import org.jmlspecs.models.JMLObjectSet;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class authentication{
	private int n_events = 1;
	private static final Integer max_integer = Utilities.max_integer;
	private static final Integer min_integer = Utilities.min_integer;
	private Thread[] events;
	public Lock lock = new ReentrantLock(true);


	/******Set definitions******/
	//@ public static constraint HASHES.equals(\old(HASHES)); 
	public static final BSet<Integer> HASHES = new Enumerated(min_integer,max_integer);

	//@ public static constraint KEYS.equals(\old(KEYS)); 
	public static final BSet<Integer> KEYS = new Enumerated(min_integer,max_integer);


	/******Constant definitions******/


	/******Axiom definitions******/


	/******Variable definitions******/
	/*@ spec_public */ private BRelation<Integer,Integer> hash;

	/*@ spec_public */ private BSet<Integer> hashes;

	/*@ spec_public */ private BSet<Integer> keys;




	/******Invariant definition******/
	/*@ public invariant
		keys.isSubset(KEYS) &&
		hashes.isSubset(HASHES) &&
		 hash.domain().equals(keys) && hash.range().isSubset(hashes) && hash.isaFunction() && BRelation.cross(keys,hashes).has(hash); */


	/******Getter and Mutator methods definition******/
	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.keys;*/
	public /*@ pure */ BSet<Integer> get_keys(){
		return this.keys;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.keys;
	    ensures this.keys == keys;*/
	public void set_keys(BSet<Integer> keys){
		this.keys = keys;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.hashes;*/
	public /*@ pure */ BSet<Integer> get_hashes(){
		return this.hashes;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.hashes;
	    ensures this.hashes == hashes;*/
	public void set_hashes(BSet<Integer> hashes){
		this.hashes = hashes;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.hash;*/
	public /*@ pure */ BRelation<Integer,Integer> get_hash(){
		return this.hash;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.hash;
	    ensures this.hash == hash;*/
	public void set_hash(BRelation<Integer,Integer> hash){
		this.hash = hash;
	}



	/*@ public normal_behavior
	    requires true;
	    assignable \everything;
	    ensures
		keys.isEmpty() &&
		hashes.isEmpty() &&
		hash.isEmpty();*/
	public authentication(){
		keys = new BSet<Integer>();
		hashes = new BSet<Integer>();
		hash = new BRelation<Integer,Integer>();

		/*events = new Thread[n_events];
		events[0] = new add_hash_key(this);

		for (int i = 0; i < n_events;i++){
			events[i].start();
		}*/
	}
}