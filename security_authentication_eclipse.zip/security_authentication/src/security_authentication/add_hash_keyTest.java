package security_authentication;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import eventb_prelude.*;

public class add_hash_keyTest {
	private authentication machine;
	
	@Before
	public void setUp() {
		machine = new authentication();	
	}

    @After
    public void tearDown() {
            //
    }

    // checking added hash-key
	@Test
	public void add_hash_key_test_01() {
		add_hash_key ahk = new add_hash_key(machine);
		Integer k = machine.KEYS.choose();
		Integer h = machine.HASHES.choose();
		assertTrue(ahk.guard_add_hash_key(h, k));
		ahk.run_add_hash_key(h, k);
		assertTrue(machine.get_hash().has(k,h));
	}

    // adding with non-existing key
	@Test
	public void add_hash_key_test_02() {
		add_hash_key ahk = new add_hash_key(machine);
		
		Integer k = 0;
		for(int i=0;;i++){
			k = new Integer(i);
			if(!(machine.KEYS.has(k))) 
				break;
		}
		//
		Integer h = machine.HASHES.choose();
		assertFalse(ahk.guard_add_hash_key(h, k));
	}	
	

}
