package autonomous_vehicle;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import eventb_prelude.Pair;


public class SET_LEFT_BORDERTest {
	private Kinetic machine;
	
	@Before
	public void setUp() {
		machine = new Kinetic();	
	}

    @After
    public void tearDown() {
            //
    }

	@Test
	public void SET_LEFT_BORDER_01() {
		Integer Vehicle = 1;
		Integer Desc = 0; // description
		Integer H = 1; // car's height
		Integer W = 1; // car's width
		Integer X = 0; // car's position, x-coordinate
		Integer Y = 0; // car's position, y-coordinate
		Integer Max = 1; // car's maximum velocity
		
		ADD_VEHICLE ac = new ADD_VEHICLE(machine);
		ac.run_ADD_VEHICLE(H, Vehicle, W, X, Y, Max);
		assertTrue(machine.get_vehicles().has(Vehicle));
		//
		Integer Finish = 11;
		Integer Lane = 12; // 
		Integer Left = 1; // 
		Integer Right = 5; // 
		Integer F = 1; 
		
		ADD_LANE al = new ADD_LANE(machine);
		al.run_ADD_LANE(  Finish,  Lane, Left, Right, F);
		
		assertTrue(machine.get_lanes().has(Lane));
		assertTrue(machine.get_finish_line().has(new Pair<Integer,Integer>(Lane,Finish)));
		assertTrue(machine.get_left_border().has(new Pair<Integer,Integer>(Lane,Left)));
		assertTrue(machine.get_right_border().has(new Pair<Integer,Integer>(Lane,Right)));
		assertTrue(machine.get_friction().has(new Pair<Integer,Integer>(Lane,F)));
		//
		
		SET_LEFT_BORDER slb = new SET_LEFT_BORDER(machine);
		int B = 5;
		slb.run_SET_LEFT_BORDER(B, Lane);
		int B2 = machine.get_right_border().apply(Lane);
		assertTrue(B==B2);
	}

}
