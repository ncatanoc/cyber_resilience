package autonomous_vehicle;

import availability_heartbeat.*;

public class KineticThreaded extends Kinetic {
	protected HeartBeatThreaded heartbeat;
	
	public KineticThreaded(HeartBeatThreaded heartbeat) {
		this.heartbeat = heartbeat;
		//
		events = new Thread[n_events];
		events[0] = new SET_MAXVEL_Threaded(this, heartbeat);
		events[1] = new SET_DRIFT_Threaded(this, heartbeat);
		events[2] = new SET_ZERO_VEL_Threaded(this, heartbeat);
		events[3] = new DELETE_OBSTACLE_Threaded(this, heartbeat);
		events[4] = new SET_LEFT_BORDER_Threaded(this, heartbeat);
		events[5] = new SET_ACC_Threaded(this, heartbeat);
		events[6] = new SET_RIGHT_BORDER_Threaded(this, heartbeat);
		events[7] = new FINISHED_LANE_Threaded(this, heartbeat);
		events[8] = new SET_VEL_Threaded(this, heartbeat); // receive
		events[9] = new ADD_LANE_Threaded(this, heartbeat);
		events[10] = new ADD_VEHICLE_Threaded(this, heartbeat); // send 
		events[11] = new DELETE_LANE_Threaded(this, heartbeat);
		events[12] = new OBJECT_COLLISION_Threaded(this, heartbeat);
		events[13] = new ADD_OBSTACLE_Threaded(this, heartbeat);
		events[14] = new SET_POS_Threaded(this, heartbeat);
		events[15] = new APPLY_FRICTION_Threaded(this, heartbeat);
		events[16] = new UPDATE_POSITION_Threaded(this, heartbeat);
		events[17] = new SET_FINISH_LINE_Threaded(this, heartbeat);
		events[18] = new DELETE_VEHICLE_Threaded(this, heartbeat);
		events[19] = new UPDATE_VEL_Threaded(this, heartbeat);
		events[20] = new WALL_COLLISION_Threaded(this, heartbeat);

		for (int i = 0; i < n_events;i++){ 
			events[i].start();
		}
	}
	
	//
	public static void main(String args[]){
		HeartBeatThreaded heartbeat = new HeartBeatThreaded();	
		KineticThreaded kinetic = new KineticThreaded(heartbeat);	
	}
}
