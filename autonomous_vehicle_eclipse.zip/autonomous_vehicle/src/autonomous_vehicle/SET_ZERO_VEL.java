package autonomous_vehicle; 

import eventb_prelude.*;
import Util.Utilities;
import availability_heartbeat.HeartBeatThreaded;

public class SET_ZERO_VEL {
	/*@ spec_public */ private Kinetic machine; // reference to the machine 

	/*@ public normal_behavior
		requires true;
		assignable \everything;
		ensures this.machine == m; */
	public SET_ZERO_VEL(Kinetic m) {
		this.machine = m;
	}

	/*@ public normal_behavior
		requires true;
 		assignable \nothing;
		ensures \result <==> (machine.get_vehicles().has(Vehicle) && (machine.get_vel().apply(Vehicle)).compareTo(new Integer(0)) < 0); */
	public /*@ pure */ boolean guard_SET_ZERO_VEL( Integer Vehicle) {
		return (machine.get_vehicles().has(Vehicle) && (machine.get_vel().apply(Vehicle)).compareTo(new Integer(0)) < 0);
	}

	/*@ public normal_behavior
		requires guard_SET_ZERO_VEL(Vehicle);
		assignable machine.vel;
		ensures guard_SET_ZERO_VEL(Vehicle) &&  machine.get_vel().equals(\old((machine.get_vel().override(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(Vehicle,0)))))); 
	 also
		requires !guard_SET_ZERO_VEL(Vehicle);
		assignable \nothing;
		ensures true; */
	public void run_SET_ZERO_VEL( Integer Vehicle){
		if(guard_SET_ZERO_VEL(Vehicle)) {
			BRelation<Integer,Integer> vel_tmp = machine.get_vel();

			machine.set_vel((vel_tmp.override(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(Vehicle,0)))));

			System.out.println("SET_ZERO_VEL executed Vehicle: " + Vehicle + " ");
		}
	}
}
