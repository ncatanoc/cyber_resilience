package availability_timestamp;

import eventb_prelude.*;
import Util.Utilities;

public class hasFailed extends Thread{
	/*@ spec_public */ private timestamp machine; // reference to the machine 

	/*@ public normal_behavior
		requires true;
		assignable \everything;
		ensures this.machine == m; */
	public hasFailed(timestamp m) {
		this.machine = m;
	}

	/*@ public normal_behavior
		requires true;
 		assignable \nothing;
		ensures \result <==> machine.get_hasFailed_enabled().equals(true); */
	public /*@ pure */ boolean guard_hasFailed() {
		return machine.get_hasFailed_enabled().equals(true);
	}

	/*@ public normal_behavior
		requires guard_hasFailed();
		assignable machine.tick_executed, machine.hasFailed_executed, machine.after_executed, machine.before_executed, machine.recover_executed, machine.recover_enabled;
		ensures guard_hasFailed() &&  machine.get_tick_executed() == \old(false) &&  machine.get_hasFailed_executed() == \old(true) &&  machine.get_after_executed() == \old(false) &&  machine.get_before_executed() == \old(false) &&  machine.get_recover_executed() == \old(false) &&  machine.get_recover_enabled() == \old(true); 
	 also
		requires !guard_hasFailed();
		assignable \nothing;
		ensures true; */
	public void run_hasFailed(){
		if(guard_hasFailed()) {
			Boolean tick_executed_tmp = machine.get_tick_executed();
			Boolean hasFailed_executed_tmp = machine.get_hasFailed_executed();
			Boolean after_executed_tmp = machine.get_after_executed();
			Boolean before_executed_tmp = machine.get_before_executed();
			Boolean recover_executed_tmp = machine.get_recover_executed();
			Boolean recover_enabled_tmp = machine.get_recover_enabled();

			machine.set_tick_executed(false);
			machine.set_hasFailed_executed(true);
			machine.set_after_executed(false);
			machine.set_before_executed(false);
			machine.set_recover_executed(false);
			machine.set_recover_enabled(true);

			System.out.println("hasFailed executed ");
		}
	}

	public void run() {
		while(true) {
			machine.lock.lock(); // start of critical section
			run_hasFailed();
			machine.lock.unlock(); // end of critical section
		}
	}
}
