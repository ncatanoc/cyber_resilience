package availability_timestamp;

import eventb_prelude.*;
import Util.Utilities;

public class after extends Thread{
	/*@ spec_public */ private timestamp machine; // reference to the machine 

	/*@ public normal_behavior
		requires true;
		assignable \everything;
		ensures this.machine == m; */
	public after(timestamp m) {
		this.machine = m;
	}

	/*@ public normal_behavior
		requires true;
 		assignable \nothing;
		ensures \result <==> (machine.get_time()).compareTo(machine.get_time_after()) > 0; */
	public /*@ pure */ boolean guard_after() {
		return (machine.get_time()).compareTo(machine.get_time_after()) > 0;
	}

	/*@ public normal_behavior
		requires guard_after();
		assignable machine.time_after, machine.tick_executed, machine.hasFailed_executed, machine.after_executed, machine.before_executed, machine.recover_executed, machine.hasFailed_enabled, machine.recover_enabled, machine.after_enabled;
		ensures guard_after() &&  machine.get_time_after() == \old(machine.get_time()) &&  machine.get_tick_executed() == \old(false) &&  machine.get_hasFailed_executed() == \old(false) &&  machine.get_after_executed() == \old(true) &&  machine.get_before_executed() == \old(false) &&  machine.get_recover_executed() == \old(false) &&  machine.get_hasFailed_enabled() == \old(((machine.get_time_before()).compareTo(machine.get_time()) > 0)) &&  machine.get_recover_enabled() == \old(((machine.get_time_before()).compareTo(machine.get_time()) > 0)) &&  machine.get_after_enabled() == \old(false); 
	 also
		requires !guard_after();
		assignable \nothing;
		ensures true; */
	public void run_after(){
		if(guard_after()) {
			Integer time_after_tmp = machine.get_time_after();
			Boolean tick_executed_tmp = machine.get_tick_executed();
			Boolean hasFailed_executed_tmp = machine.get_hasFailed_executed();
			Boolean after_executed_tmp = machine.get_after_executed();
			Boolean before_executed_tmp = machine.get_before_executed();
			Boolean recover_executed_tmp = machine.get_recover_executed();
			Boolean hasFailed_enabled_tmp = machine.get_hasFailed_enabled();
			Boolean recover_enabled_tmp = machine.get_recover_enabled();
			Boolean after_enabled_tmp = machine.get_after_enabled();

			machine.set_time_after(machine.get_time());
			machine.set_tick_executed(false);
			machine.set_hasFailed_executed(false);
			machine.set_after_executed(true);
			machine.set_before_executed(false);
			machine.set_recover_executed(false);
			machine.set_hasFailed_enabled(((machine.get_time_before()).compareTo(machine.get_time()) > 0));
			machine.set_recover_enabled(((machine.get_time_before()).compareTo(machine.get_time()) > 0));
			machine.set_after_enabled(false);

			System.out.println("after executed ");
		}
	}

	public void run() {
		while(true) {
			machine.lock.lock(); // start of critical section
			run_after();
			machine.lock.unlock(); // end of critical section
		}
	}
}
