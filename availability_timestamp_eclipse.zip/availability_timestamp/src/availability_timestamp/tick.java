package availability_timestamp;

import eventb_prelude.*;
import Util.Utilities;

public class tick extends Thread{
	/*@ spec_public */ private timestamp machine; // reference to the machine 

	/*@ public normal_behavior
		requires true;
		assignable \everything;
		ensures this.machine == m; */
	public tick(timestamp m) {
		this.machine = m;
	}

	/*@ public normal_behavior
		requires true;
 		assignable \nothing;
		ensures \result <==> true; */
	public /*@ pure */ boolean guard_tick() {
		return true;
	}

	/*@ public normal_behavior
		requires guard_tick();
		assignable machine.time, machine.tick_executed, machine.hasFailed_executed, machine.after_executed, machine.before_executed, machine.recover_executed, machine.before_enabled, machine.after_enabled;
		ensures guard_tick() &&  machine.get_time() == \old(new Integer(machine.get_time() + 1)) &&  machine.get_tick_executed() == \old(true) &&  machine.get_hasFailed_executed() == \old(false) &&  machine.get_after_executed() == \old(false) &&  machine.get_before_executed() == \old(false) &&  machine.get_recover_executed() == \old(false) &&  machine.get_before_enabled() == \old(((new Integer(machine.get_time() + 1)).compareTo(machine.get_time_before()) > 0)) &&  machine.get_after_enabled() == \old(((new Integer(machine.get_time() + 1)).compareTo(machine.get_time_after()) > 0)); 
	 also
		requires !guard_tick();
		assignable \nothing;
		ensures true; */
	public void run_tick(){
		if(guard_tick()) {
			Integer time_tmp = machine.get_time();
			Boolean tick_executed_tmp = machine.get_tick_executed();
			Boolean hasFailed_executed_tmp = machine.get_hasFailed_executed();
			Boolean after_executed_tmp = machine.get_after_executed();
			Boolean before_executed_tmp = machine.get_before_executed();
			Boolean recover_executed_tmp = machine.get_recover_executed();
			Boolean before_enabled_tmp = machine.get_before_enabled();
			Boolean after_enabled_tmp = machine.get_after_enabled();

			machine.set_time(new Integer(time_tmp + 1));
			machine.set_tick_executed(true);
			machine.set_hasFailed_executed(false);
			machine.set_after_executed(false);
			machine.set_before_executed(false);
			machine.set_recover_executed(false);
			machine.set_before_enabled(((new Integer(time_tmp + 1)).compareTo(machine.get_time_before()) > 0));
			machine.set_after_enabled(((new Integer(time_tmp + 1)).compareTo(machine.get_time_after()) > 0));

			System.out.println("tick executed ");
		}
	}

	public void run() {
		while(true) {
			machine.lock.lock(); // start of critical section
			run_tick();
			machine.lock.unlock(); // end of critical section
		}
	}
}
