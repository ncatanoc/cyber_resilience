package availability_timestamp;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class recoverTest {
	private timestamp machine;
	
	@Before
	public void setUp() {
		machine = new timestamp();	
	}

    @After
    public void tearDown() {
            //
    }

    // the system recovers after a failure
	@Test
	public void rollback_test_01() {
		// after is executed after ticking
		tick t = new tick(machine);
		t.run_tick();
		//
		after a = new after(machine);
		assertTrue(a.guard_after());
		a.run_after();
		//
		t.run_tick();
		// before is executed
		before b = new before(machine);
		assertTrue(b.guard_before());
		b.run_before();
		// the system has failed
		hasFailed hf = new hasFailed(machine);
		assertTrue(hf.guard_hasFailed());
		//
		recover rc = new recover(machine);
		rc.run_recover();
		assertFalse(hf.guard_hasFailed());
	}

}
