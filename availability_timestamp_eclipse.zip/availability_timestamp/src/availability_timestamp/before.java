package availability_timestamp;

import eventb_prelude.*;
import Util.Utilities;

public class before extends Thread{
	/*@ spec_public */ private timestamp machine; // reference to the machine 

	/*@ public normal_behavior
		requires true;
		assignable \everything;
		ensures this.machine == m; */
	public before(timestamp m) {
		this.machine = m;
	}

	/*@ public normal_behavior
		requires true;
 		assignable \nothing;
		ensures \result <==> (machine.get_time()).compareTo(machine.get_time_before()) > 0; */
	public /*@ pure */ boolean guard_before() {
		return (machine.get_time()).compareTo(machine.get_time_before()) > 0;
	}

	/*@ public normal_behavior
		requires guard_before();
		assignable machine.time_before, machine.tick_executed, machine.hasFailed_executed, machine.after_executed, machine.before_executed, machine.recover_executed, machine.hasFailed_enabled, machine.recover_enabled, machine.before_enabled;
		ensures guard_before() &&  machine.get_time_before() == \old(machine.get_time()) &&  machine.get_tick_executed() == \old(false) &&  machine.get_hasFailed_executed() == \old(false) &&  machine.get_after_executed() == \old(false) &&  machine.get_before_executed() == \old(true) &&  machine.get_recover_executed() == \old(false) &&  machine.get_hasFailed_enabled() == \old(((machine.get_time()).compareTo(machine.get_time_after()) > 0)) &&  machine.get_recover_enabled() == \old(((machine.get_time()).compareTo(machine.get_time_after()) > 0)) &&  machine.get_before_enabled() == \old(false); 
	 also
		requires !guard_before();
		assignable \nothing;
		ensures true; */
	public void run_before(){
		if(guard_before()) {
			Integer time_before_tmp = machine.get_time_before();
			Boolean tick_executed_tmp = machine.get_tick_executed();
			Boolean hasFailed_executed_tmp = machine.get_hasFailed_executed();
			Boolean after_executed_tmp = machine.get_after_executed();
			Boolean before_executed_tmp = machine.get_before_executed();
			Boolean recover_executed_tmp = machine.get_recover_executed();
			Boolean hasFailed_enabled_tmp = machine.get_hasFailed_enabled();
			Boolean recover_enabled_tmp = machine.get_recover_enabled();
			Boolean before_enabled_tmp = machine.get_before_enabled();

			machine.set_time_before(machine.get_time());
			machine.set_tick_executed(false);
			machine.set_hasFailed_executed(false);
			machine.set_after_executed(false);
			machine.set_before_executed(true);
			machine.set_recover_executed(false);
			machine.set_hasFailed_enabled(((machine.get_time()).compareTo(machine.get_time_after()) > 0));
			machine.set_recover_enabled(((machine.get_time()).compareTo(machine.get_time_after()) > 0));
			machine.set_before_enabled(false);

			System.out.println("before executed ");
		}
	}

	public void run() {
		while(true) {
			machine.lock.lock(); // start of critical section
			run_before();
			machine.lock.unlock(); // end of critical section
		}
	}
}
