package availability_timestamp;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class hasFailedTest {

	private timestamp machine;
	
	@Before
	public void setUp() {
		machine = new timestamp();	
	}

    @After
    public void tearDown() {
            //
    }

    // the initial system is not in a failed state
    @Test
	public void hasFailed_test_01() {
		hasFailed ch = new hasFailed(machine);
		assertFalse(ch.guard_hasFailed());
		ch.run_hasFailed();
	}
	
	// the sequence 'after', 'before' is executed
    // then the system 'hasFailed'
	@Test
	public void hasFailed_test_02() {
		tick t = new tick(machine);
		t.run_tick();
		// 'after' is executed 
		after a = new after(machine);
		assertTrue(a.guard_after());
		a.run_after();
		//
		t.run_tick();
		// 'before' is executed
		before b = new before(machine);
		assertTrue(b.guard_before());
		b.run_before();
		// the system 'hasFailed'
		hasFailed hf = new hasFailed(machine);
		assertTrue(hf.guard_hasFailed());
	}
	
	/*
	after hasFailed executed
	 ( 
		always recover enabled
	  )
	*/
	@Test
	public void hasFailed_test_inv1() {
		tick t = new tick(machine);
		t.run_tick();
		// 'after' is executed 
		after a = new after(machine);
		assertTrue(a.guard_after());
		a.run_after();
		//
		t.run_tick();
		// 'before' is executed
		before b = new before(machine);
		assertTrue(b.guard_before());
		b.run_before();
		// the system 'hasFailed'
		hasFailed hf = new hasFailed(machine);
		assertTrue(hf.guard_hasFailed());
		//
		recover r = new recover(machine);
		assertTrue(r.guard_recover());
		//
		r.run_recover();
		assertFalse(r.guard_recover());
	}
	
	

}
