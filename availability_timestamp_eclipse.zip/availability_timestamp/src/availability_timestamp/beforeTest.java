package availability_timestamp;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class beforeTest {
	private timestamp machine;
	
	@Before
	public void setUp() {
		machine = new timestamp();	
	}

    @After
    public void tearDown() {
            //
    }

    // time before can be set initially
	@Test
	public void before_test_01() {
		tick t = new tick(machine);
		assertTrue(t.guard_tick());
		t.run_tick(); // time = 1
		int time_1 = machine.get_time();
		before b = new before(machine);
		assertTrue(b.guard_before());
		b.run_before(); // time_before is set to time = 1
		assertTrue(machine.get_time_before() == time_1);
	}
	
	/*
	after before executed
	 ( 
		always before disabled
	  )
	*/
	@Test
	public void before_test_inv2() {
		tick t = new tick(machine);
		assertTrue(t.guard_tick());
		t.run_tick(); // time = 1
		before b = new before(machine);
		// 'before' is executed
		assertTrue(b.guard_before());
		b.run_before(); // time_before is set to 1
		// 'before' is disabled 
		assertFalse(b.guard_before());
	}
	
	

}
