package availability_timestamp;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ afterTest.class, beforeTest.class, hasFailedTest.class,
		recoverTest.class, tickTest.class })
public class AllTests {

}
