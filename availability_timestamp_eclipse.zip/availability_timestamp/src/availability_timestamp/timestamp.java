package availability_timestamp;

import eventb_prelude.*;
import Util.*;
//@ model import org.jmlspecs.models.JMLObjectSet;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class timestamp{
	private int n_events = 5;
	private static final Integer max_integer = Utilities.max_integer;
	private static final Integer min_integer = Utilities.min_integer;
	private Thread[] events;
	public Lock lock = new ReentrantLock(true);


	/******Set definitions******/
	//@ public static constraint INFO.equals(\old(INFO)); 
	public static final BSet<Integer> INFO = new Enumerated(min_integer,max_integer);

	//@ public static constraint NODES.equals(\old(NODES)); 
	public static final BSet<Integer> NODES = new Enumerated(min_integer,max_integer);


	/******Constant definitions******/
	//@ public static constraint Tslot.equals(\old(Tslot)); 
	public static final Integer Tslot = 40;



	/******Axiom definitions******/
	/*@ public static invariant NAT.instance.has(Tslot) && (Tslot).compareTo(new Integer(0)) > 0; */


	/******Variable definitions******/
	/*@ spec_public */ private Boolean after_enabled;

	/*@ spec_public */ private Boolean after_executed;

	/*@ spec_public */ private Boolean before_enabled;

	/*@ spec_public */ private Boolean before_executed;

	/*@ spec_public */ private Boolean hasFailed_enabled;

	/*@ spec_public */ private Boolean hasFailed_executed;

	/*@ spec_public */ private Boolean inv1;

	/*@ spec_public */ private Boolean inv2;

	/*@ spec_public */ private Boolean inv3;

	/*@ spec_public */ private Boolean recover_enabled;

	/*@ spec_public */ private Boolean recover_executed;

	/*@ spec_public */ private Boolean tick_enabled;

	/*@ spec_public */ private Boolean tick_executed;

	/*@ spec_public */ private Integer time;

	/*@ spec_public */ private Integer time_after;

	/*@ spec_public */ private Integer time_before;




	/******Invariant definition******/
	/*@ public invariant
		NAT.instance.has(time_before) &&
		NAT.instance.has(time_after) &&
		NAT.instance.has(time) &&
		(time).compareTo(time_before) >= 0 &&
		(time).compareTo(time_after) >= 0 &&
		BOOL.instance.has(tick_enabled) &&
		tick_enabled.equals(true) &&
		BOOL.instance.has(hasFailed_enabled) &&
		hasFailed_enabled.equals(((time_before).compareTo(time_after) > 0)) &&
		BOOL.instance.has(before_enabled) &&
		before_enabled.equals(((time).compareTo(time_before) > 0)) &&
		BOOL.instance.has(after_enabled) &&
		after_enabled.equals(((time).compareTo(time_after) > 0)) &&
		BOOL.instance.has(recover_enabled) &&
		recover_enabled.equals(((time_before).compareTo(time_after) > 0)) &&
		BOOL.instance.has(tick_executed) &&
		BOOL.instance.has(before_executed) &&
		BOOL.instance.has(after_executed) &&
		BOOL.instance.has(hasFailed_executed) &&
		BOOL.instance.has(recover_executed) &&
		BOOL.instance.has(inv1) &&
		inv1.equals(true) &&
		inv1.equals((((hasFailed_executed.equals(true)) ==> (recover_enabled.equals(true))))) &&
		BOOL.instance.has(inv2) &&
		inv2.equals(true) &&
		inv2.equals((((before_executed.equals(true)) ==> (before_enabled.equals(false))))) &&
		BOOL.instance.has(inv3) &&
		inv3.equals(true) &&
		inv3.equals((((after_executed.equals(true)) ==> (after_enabled.equals(false))))); */


	/******Getter and Mutator methods definition******/
	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.hasFailed_executed;*/
	public /*@ pure */ Boolean get_hasFailed_executed(){
		return this.hasFailed_executed;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.hasFailed_executed;
	    ensures this.hasFailed_executed == hasFailed_executed;*/
	public void set_hasFailed_executed(Boolean hasFailed_executed){
		this.hasFailed_executed = hasFailed_executed;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.recover_enabled;*/
	public /*@ pure */ Boolean get_recover_enabled(){
		return this.recover_enabled;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.recover_enabled;
	    ensures this.recover_enabled == recover_enabled;*/
	public void set_recover_enabled(Boolean recover_enabled){
		this.recover_enabled = recover_enabled;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.after_executed;*/
	public /*@ pure */ Boolean get_after_executed(){
		return this.after_executed;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.after_executed;
	    ensures this.after_executed == after_executed;*/
	public void set_after_executed(Boolean after_executed){
		this.after_executed = after_executed;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.inv2;*/
	public /*@ pure */ Boolean get_inv2(){
		return this.inv2;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.inv2;
	    ensures this.inv2 == inv2;*/
	public void set_inv2(Boolean inv2){
		this.inv2 = inv2;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.inv1;*/
	public /*@ pure */ Boolean get_inv1(){
		return this.inv1;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.inv1;
	    ensures this.inv1 == inv1;*/
	public void set_inv1(Boolean inv1){
		this.inv1 = inv1;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.inv3;*/
	public /*@ pure */ Boolean get_inv3(){
		return this.inv3;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.inv3;
	    ensures this.inv3 == inv3;*/
	public void set_inv3(Boolean inv3){
		this.inv3 = inv3;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.tick_enabled;*/
	public /*@ pure */ Boolean get_tick_enabled(){
		return this.tick_enabled;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.tick_enabled;
	    ensures this.tick_enabled == tick_enabled;*/
	public void set_tick_enabled(Boolean tick_enabled){
		this.tick_enabled = tick_enabled;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.time_before;*/
	public /*@ pure */ Integer get_time_before(){
		return this.time_before;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.time_before;
	    ensures this.time_before == time_before;*/
	public void set_time_before(Integer time_before){
		this.time_before = time_before;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.hasFailed_enabled;*/
	public /*@ pure */ Boolean get_hasFailed_enabled(){
		return this.hasFailed_enabled;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.hasFailed_enabled;
	    ensures this.hasFailed_enabled == hasFailed_enabled;*/
	public void set_hasFailed_enabled(Boolean hasFailed_enabled){
		this.hasFailed_enabled = hasFailed_enabled;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.before_executed;*/
	public /*@ pure */ Boolean get_before_executed(){
		return this.before_executed;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.before_executed;
	    ensures this.before_executed == before_executed;*/
	public void set_before_executed(Boolean before_executed){
		this.before_executed = before_executed;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.tick_executed;*/
	public /*@ pure */ Boolean get_tick_executed(){
		return this.tick_executed;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.tick_executed;
	    ensures this.tick_executed == tick_executed;*/
	public void set_tick_executed(Boolean tick_executed){
		this.tick_executed = tick_executed;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.time;*/
	public /*@ pure */ Integer get_time(){
		return this.time;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.time;
	    ensures this.time == time;*/
	public void set_time(Integer time){
		this.time = time;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.time_after;*/
	public /*@ pure */ Integer get_time_after(){
		return this.time_after;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.time_after;
	    ensures this.time_after == time_after;*/
	public void set_time_after(Integer time_after){
		this.time_after = time_after;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.before_enabled;*/
	public /*@ pure */ Boolean get_before_enabled(){
		return this.before_enabled;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.before_enabled;
	    ensures this.before_enabled == before_enabled;*/
	public void set_before_enabled(Boolean before_enabled){
		this.before_enabled = before_enabled;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.recover_executed;*/
	public /*@ pure */ Boolean get_recover_executed(){
		return this.recover_executed;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.recover_executed;
	    ensures this.recover_executed == recover_executed;*/
	public void set_recover_executed(Boolean recover_executed){
		this.recover_executed = recover_executed;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.after_enabled;*/
	public /*@ pure */ Boolean get_after_enabled(){
		return this.after_enabled;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.after_enabled;
	    ensures this.after_enabled == after_enabled;*/
	public void set_after_enabled(Boolean after_enabled){
		this.after_enabled = after_enabled;
	}



	/*@ public normal_behavior
	    requires true;
	    assignable \everything;
	    ensures
		time_before == 0 &&
		time_after == 0 &&
		time == 0 &&
		tick_enabled == true &&
		before_enabled == false &&
		after_enabled == false &&
		hasFailed_enabled == false &&
		recover_enabled == false &&
		tick_executed == false &&
		hasFailed_executed == false &&
		before_executed == false &&
		after_executed == false &&
		recover_executed == false &&
		inv1 == true &&
		inv2 == true &&
		inv3 == true;*/
	public timestamp(){
		time_before = 0;
		time_after = 0;
		time = 0;
		tick_enabled = true;
		before_enabled = false;
		after_enabled = false;
		hasFailed_enabled = false;
		recover_enabled = false;
		tick_executed = false;
		hasFailed_executed = false;
		before_executed = false;
		after_executed = false;
		recover_executed = false;
		inv1 = true;
		inv2 = true;
		inv3 = true;

		/*events = new Thread[n_events];
		events[0] = new hasFailed(this);
		events[1] = new recover(this);
		events[2] = new before(this);
		events[3] = new tick(this);
		events[4] = new after(this);

		for (int i = 0; i < n_events;i++){
			events[i].start();
		}*/
	}
}