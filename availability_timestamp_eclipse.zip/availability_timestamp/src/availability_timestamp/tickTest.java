package availability_timestamp;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class tickTest {
	private timestamp machine;
	
	@Before
	public void setUp() {
		machine = new timestamp();	
	}

    @After
    public void tearDown() {
            //
    }

    // tick increases the time
	@Test
	public void tick_test_01() {
		//
		tick t = new tick(machine);
		assertTrue(t.guard_tick());
		int time_0 = machine.get_time();
		t.run_tick();
		int time_1 = machine.get_time();
		assertTrue(time_1 > time_0);
	}
	

}
