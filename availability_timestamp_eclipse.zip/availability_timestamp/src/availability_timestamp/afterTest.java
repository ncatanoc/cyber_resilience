package availability_timestamp;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class afterTest {

	private timestamp machine;
	
	@Before
	public void setUp() {
		machine = new timestamp();	
	}

    @After
    public void tearDown() {
            //
    }

	/*
	after before executed
	 ( 
		always before disabled
	  )
	*/
	@Test
	public void after_test_inv3() {
		// after is executed after ticking
		tick t = new tick(machine);
		t.run_tick();
		//
		after a = new after(machine);
		assertTrue(a.guard_after());
		a.run_after();
		//
		assertFalse(a.guard_after());
	}
	

}
