package availability_pingecho;

import eventb_prelude.*;
import Util.*;
//@ model import org.jmlspecs.models.JMLObjectSet;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class pingecho{
	private int n_events = 6;
	private static final Integer max_integer = Utilities.max_integer;
	private static final Integer min_integer = Utilities.min_integer;
	private Thread[] events;
	public Lock lock = new ReentrantLock(true);


	/******Set definitions******/

	/******Constant definitions******/
	//@ public static constraint Tslot.equals(\old(Tslot)); 
	public static final Integer Tslot = 41;



	/******Axiom definitions******/
	/*@ public static invariant NAT.instance.has(Tslot) && (Tslot).compareTo(new Integer(0)) > 0; */


	/******Variable definitions******/
	/*@ spec_public */ private Boolean fail_enabled;

	/*@ spec_public */ private Boolean fail_executed;

	/*@ spec_public */ private Boolean hasFailed_enabled;

	/*@ spec_public */ private Boolean hasFailed_executed;

	/*@ spec_public */ private Boolean inv1;

	/*@ spec_public */ private Boolean inv2;

	/*@ spec_public */ private Boolean inv3;

	/*@ spec_public */ private Boolean inv4;

	/*@ spec_public */ private Boolean inv5;

	/*@ spec_public */ private Boolean inv6;

	/*@ spec_public */ private Boolean ping;

	/*@ spec_public */ private Boolean receive_enabled;

	/*@ spec_public */ private Boolean receive_executed;

	/*@ spec_public */ private Boolean rollback_enabled;

	/*@ spec_public */ private Boolean rollback_executed;

	/*@ spec_public */ private Boolean send_enabled;

	/*@ spec_public */ private Boolean send_executed;

	/*@ spec_public */ private Boolean tick_enabled;

	/*@ spec_public */ private Boolean tick_executed;

	/*@ spec_public */ private Integer time;




	/******Invariant definition******/
	/*@ public invariant
		BOOL.instance.has(ping) &&
		NAT.instance.has(time) &&
		BOOL.instance.has(send_executed) &&
		BOOL.instance.has(send_enabled) &&
		BOOL.instance.has(receive_executed) &&
		BOOL.instance.has(receive_enabled) &&
		BOOL.instance.has(tick_executed) &&
		BOOL.instance.has(tick_enabled) &&
		BOOL.instance.has(rollback_executed) &&
		BOOL.instance.has(rollback_enabled) &&
		BOOL.instance.has(hasFailed_executed) &&
		BOOL.instance.has(hasFailed_enabled) &&
		BOOL.instance.has(fail_executed) &&
		BOOL.instance.has(fail_enabled) &&
		send_enabled.equals((ping.equals(false))) &&
		receive_enabled.equals((ping.equals(true) && (time).compareTo(new Integer(0)) > 0)) &&
		tick_enabled.equals(((time).compareTo(new Integer(0)) > 0)) &&
		rollback_enabled.equals(true) &&
		hasFailed_enabled.equals((ping.equals(true) && time.equals(new Integer(0)))) &&
		fail_enabled.equals(true) &&
		BOOL.instance.has(inv1) &&
		inv1.equals(true) &&
		inv1.equals((((send_executed.equals(true)) ==> (((hasFailed_enabled.equals(true) || fail_executed.equals(true)) ==> (receive_enabled.equals(false))) || receive_enabled.equals(true))))) &&
		BOOL.instance.has(inv2) &&
		inv2.equals(true) &&
		inv2.equals((((fail_executed.equals(true)) ==> (((rollback_executed.equals(true)) ==> (hasFailed_enabled.equals(false))) || hasFailed_enabled.equals(true))))) &&
		BOOL.instance.has(inv3) &&
		inv3.equals(true) &&
		inv3.equals((((send_executed.equals(true)) ==> (((rollback_executed.equals(true) || receive_executed.equals(true)) ==> (send_enabled.equals(true))) || send_enabled.equals(false))))) &&
		BOOL.instance.has(inv4) &&
		inv4.equals(true) &&
		inv4.equals((((hasFailed_enabled.equals(true)) ==> (rollback_enabled.equals(true))))) &&
		BOOL.instance.has(inv5) &&
		inv5.equals(true) &&
		inv5.equals((((hasFailed_enabled.equals(true)) ==> (((rollback_executed.equals(true)) ==> (send_enabled.equals(true))) || send_enabled.equals(true))))) &&
		BOOL.instance.has(inv6) &&
		inv6.equals(true) &&
		inv6.equals((((hasFailed_enabled.equals(true)) ==> (((send_executed.equals(true)) ==> (receive_enabled.equals(true))) || receive_enabled.equals(false))))); */


	/******Getter and Mutator methods definition******/
	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.hasFailed_executed;*/
	public /*@ pure */ Boolean get_hasFailed_executed(){
		return this.hasFailed_executed;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.hasFailed_executed;
	    ensures this.hasFailed_executed == hasFailed_executed;*/
	public void set_hasFailed_executed(Boolean hasFailed_executed){
		this.hasFailed_executed = hasFailed_executed;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.receive_executed;*/
	public /*@ pure */ Boolean get_receive_executed(){
		return this.receive_executed;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.receive_executed;
	    ensures this.receive_executed == receive_executed;*/
	public void set_receive_executed(Boolean receive_executed){
		this.receive_executed = receive_executed;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.ping;*/
	public /*@ pure */ Boolean get_ping(){
		return this.ping;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.ping;
	    ensures this.ping == ping;*/
	public void set_ping(Boolean ping){
		this.ping = ping;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.rollback_executed;*/
	public /*@ pure */ Boolean get_rollback_executed(){
		return this.rollback_executed;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.rollback_executed;
	    ensures this.rollback_executed == rollback_executed;*/
	public void set_rollback_executed(Boolean rollback_executed){
		this.rollback_executed = rollback_executed;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.fail_executed;*/
	public /*@ pure */ Boolean get_fail_executed(){
		return this.fail_executed;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.fail_executed;
	    ensures this.fail_executed == fail_executed;*/
	public void set_fail_executed(Boolean fail_executed){
		this.fail_executed = fail_executed;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.fail_enabled;*/
	public /*@ pure */ Boolean get_fail_enabled(){
		return this.fail_enabled;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.fail_enabled;
	    ensures this.fail_enabled == fail_enabled;*/
	public void set_fail_enabled(Boolean fail_enabled){
		this.fail_enabled = fail_enabled;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.inv2;*/
	public /*@ pure */ Boolean get_inv2(){
		return this.inv2;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.inv2;
	    ensures this.inv2 == inv2;*/
	public void set_inv2(Boolean inv2){
		this.inv2 = inv2;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.inv1;*/
	public /*@ pure */ Boolean get_inv1(){
		return this.inv1;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.inv1;
	    ensures this.inv1 == inv1;*/
	public void set_inv1(Boolean inv1){
		this.inv1 = inv1;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.inv4;*/
	public /*@ pure */ Boolean get_inv4(){
		return this.inv4;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.inv4;
	    ensures this.inv4 == inv4;*/
	public void set_inv4(Boolean inv4){
		this.inv4 = inv4;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.inv3;*/
	public /*@ pure */ Boolean get_inv3(){
		return this.inv3;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.inv3;
	    ensures this.inv3 == inv3;*/
	public void set_inv3(Boolean inv3){
		this.inv3 = inv3;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.tick_enabled;*/
	public /*@ pure */ Boolean get_tick_enabled(){
		return this.tick_enabled;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.tick_enabled;
	    ensures this.tick_enabled == tick_enabled;*/
	public void set_tick_enabled(Boolean tick_enabled){
		this.tick_enabled = tick_enabled;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.inv6;*/
	public /*@ pure */ Boolean get_inv6(){
		return this.inv6;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.inv6;
	    ensures this.inv6 == inv6;*/
	public void set_inv6(Boolean inv6){
		this.inv6 = inv6;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.send_executed;*/
	public /*@ pure */ Boolean get_send_executed(){
		return this.send_executed;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.send_executed;
	    ensures this.send_executed == send_executed;*/
	public void set_send_executed(Boolean send_executed){
		this.send_executed = send_executed;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.inv5;*/
	public /*@ pure */ Boolean get_inv5(){
		return this.inv5;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.inv5;
	    ensures this.inv5 == inv5;*/
	public void set_inv5(Boolean inv5){
		this.inv5 = inv5;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.hasFailed_enabled;*/
	public /*@ pure */ Boolean get_hasFailed_enabled(){
		return this.hasFailed_enabled;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.hasFailed_enabled;
	    ensures this.hasFailed_enabled == hasFailed_enabled;*/
	public void set_hasFailed_enabled(Boolean hasFailed_enabled){
		this.hasFailed_enabled = hasFailed_enabled;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.send_enabled;*/
	public /*@ pure */ Boolean get_send_enabled(){
		return this.send_enabled;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.send_enabled;
	    ensures this.send_enabled == send_enabled;*/
	public void set_send_enabled(Boolean send_enabled){
		this.send_enabled = send_enabled;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.receive_enabled;*/
	public /*@ pure */ Boolean get_receive_enabled(){
		return this.receive_enabled;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.receive_enabled;
	    ensures this.receive_enabled == receive_enabled;*/
	public void set_receive_enabled(Boolean receive_enabled){
		this.receive_enabled = receive_enabled;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.tick_executed;*/
	public /*@ pure */ Boolean get_tick_executed(){
		return this.tick_executed;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.tick_executed;
	    ensures this.tick_executed == tick_executed;*/
	public void set_tick_executed(Boolean tick_executed){
		this.tick_executed = tick_executed;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.time;*/
	public /*@ pure */ Integer get_time(){
		return this.time;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.time;
	    ensures this.time == time;*/
	public void set_time(Integer time){
		this.time = time;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.rollback_enabled;*/
	public /*@ pure */ Boolean get_rollback_enabled(){
		return this.rollback_enabled;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.rollback_enabled;
	    ensures this.rollback_enabled == rollback_enabled;*/
	public void set_rollback_enabled(Boolean rollback_enabled){
		this.rollback_enabled = rollback_enabled;
	}



	/*@ public normal_behavior
	    requires true;
	    assignable \everything;
	    ensures
		ping == false &&
		time == 0 &&
		send_executed == false &&
		send_enabled == true &&
		receive_executed == false &&
		receive_enabled == false &&
		tick_executed == false &&
		tick_enabled == false &&
		rollback_executed == false &&
		rollback_enabled == true &&
		hasFailed_executed == false &&
		hasFailed_enabled == false &&
		fail_executed == false &&
		fail_enabled == true &&
		inv1 == true &&
		inv2 == true &&
		inv3 == true &&
		inv4 == true &&
		inv5 == true &&
		inv6 == true;*/
	public pingecho(){
		ping = false;
		time = 0;
		send_executed = false;
		send_enabled = true;
		receive_executed = false;
		receive_enabled = false;
		tick_executed = false;
		tick_enabled = false;
		rollback_executed = false;
		rollback_enabled = true;
		hasFailed_executed = false;
		hasFailed_enabled = false;
		fail_executed = false;
		fail_enabled = true;
		inv1 = true;
		inv2 = true;
		inv3 = true;
		inv4 = true;
		inv5 = true;
		inv6 = true;

		/*
		events = new Thread[n_events];
		events[0] = new hasFailed(this);
		events[1] = new rollback(this);
		events[2] = new receive(this);
		events[3] = new fail(this);
		events[4] = new tick(this);
		events[5] = new send(this);

		for (int i = 0; i < n_events;i++){
			events[i].start();
		}*/
	}
}