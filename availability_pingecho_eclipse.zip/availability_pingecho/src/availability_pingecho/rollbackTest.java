package availability_pingecho;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class rollbackTest {

	private pingecho machine;
	
	@Before
	public void setUp() {
		machine = new pingecho();	
	}

    @After
    public void tearDown() {
            //
    }

    // the system may rollback after failing
	@Test
	public void rollback_test_01() {
		// the system beats
		send s = new send(machine);
		assertTrue(s.guard_send());
		s.run_send();
		// the clock ticks until the receiver runs out of time
		tick t = new tick(machine);
		assertTrue(t.guard_tick());
		while(t.guard_tick()) {
			t.run_tick();
		}
		assertTrue(machine.get_time()==0);
		hasFailed hf = new hasFailed(machine);
		assertTrue(hf.guard_hasFailed());
		hf.run_hasFailed();
		//
		rollback rb = new rollback(machine);
		assertTrue(rb.guard_rollback());
		rb.run_rollback();
		assertFalse(hf.guard_hasFailed());
		assertFalse(machine.get_ping());
	}

	
	// system can rollback even if no failure has happened
	@Test
	public void rollback_test_02() {
		// the system beats
		send s = new send(machine);
		assertTrue(s.guard_send());
		s.run_send();
		// we check that there is no failure at this point
		hasFailed hf = new hasFailed(machine);
		assertFalse(hf.guard_hasFailed());
		// the system cannot rollback
		rollback rb = new rollback(machine);
		assertFalse(rb.guard_rollback());
	}
	

}
