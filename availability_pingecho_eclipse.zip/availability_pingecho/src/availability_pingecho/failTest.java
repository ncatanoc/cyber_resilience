package availability_pingecho;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class failTest {
	private pingecho machine;
	
	@Before
	public void setUp() {
		machine = new pingecho();	
	}

    @After
    public void tearDown() {
            //
    }

    // the system can fail just after it is created
	@Test
	public void fail_test_01() {
		fail f = new fail(machine);
		assertTrue(f.guard_fail());
	}

    // the system can fail just after beating
	@Test
	public void fail_test_02() {
		fail f = new fail(machine);
		send s = new send(machine);
		assertTrue(s.guard_send());
		s.run_send();
		assertTrue(f.guard_fail());
	}

    // the system can fail just after acknowledging a beat
	@Test
	public void fail_test_03() {
		fail f = new fail(machine);
		send s = new send(machine);
		assertTrue(s.guard_send());
		s.run_send();
		//
		receive r = new receive(machine);
		assertTrue(r.guard_receive());
		r.run_receive();
		//
		assertTrue(f.guard_fail());
	}


}
