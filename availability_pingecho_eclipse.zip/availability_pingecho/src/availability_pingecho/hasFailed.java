package availability_pingecho;

import eventb_prelude.*;
import Util.Utilities;

public class hasFailed extends Thread{
	/*@ spec_public */ private pingecho machine; // reference to the machine 

	/*@ public normal_behavior
		requires true;
		assignable \everything;
		ensures this.machine == m; */
	public hasFailed(pingecho m) {
		this.machine = m;
	}

	/*@ public normal_behavior
		requires true;
 		assignable \nothing;
		ensures \result <==> machine.get_time().equals(new Integer(0)) && machine.get_ping().equals(true); */
	public /*@ pure */ boolean guard_hasFailed() {
		return machine.get_time().equals(new Integer(0)) && machine.get_ping().equals(true);
	}

	/*@ public normal_behavior
		requires guard_hasFailed();
		assignable machine.send_enabled, machine.receive_enabled, machine.rollback_enabled, machine.send_executed, machine.receive_executed, machine.rollback_executed, machine.hasFailed_executed, machine.fail_executed;
		ensures guard_hasFailed() &&  machine.get_send_enabled() == \old(false) &&  machine.get_receive_enabled() == \old(false) &&  machine.get_rollback_enabled() == \old(true) &&  machine.get_send_executed() == \old(false) &&  machine.get_receive_executed() == \old(false) &&  machine.get_rollback_executed() == \old(false) &&  machine.get_hasFailed_executed() == \old(true) &&  machine.get_fail_executed() == \old(false); 
	 also
		requires !guard_hasFailed();
		assignable \nothing;
		ensures true; */
	public void run_hasFailed(){
		if(guard_hasFailed()) {
			Boolean send_enabled_tmp = machine.get_send_enabled();
			Boolean receive_enabled_tmp = machine.get_receive_enabled();
			Boolean rollback_enabled_tmp = machine.get_rollback_enabled();
			Boolean send_executed_tmp = machine.get_send_executed();
			Boolean receive_executed_tmp = machine.get_receive_executed();
			Boolean rollback_executed_tmp = machine.get_rollback_executed();
			Boolean hasFailed_executed_tmp = machine.get_hasFailed_executed();
			Boolean fail_executed_tmp = machine.get_fail_executed();

			machine.set_send_enabled(false);
			machine.set_receive_enabled(false);
			machine.set_rollback_enabled(true);
			machine.set_send_executed(false);
			machine.set_receive_executed(false);
			machine.set_rollback_executed(false);
			machine.set_hasFailed_executed(true);
			machine.set_fail_executed(false);

			System.out.println("hasFailed executed ");
		}
	}

	public void run() {
		while(true) {
			machine.lock.lock(); // start of critical section
			run_hasFailed();
			machine.lock.unlock(); // end of critical section
		}
	}
}
