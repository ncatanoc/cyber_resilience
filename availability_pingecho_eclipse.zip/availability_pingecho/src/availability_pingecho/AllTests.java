package availability_pingecho;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ failTest.class, hasFailedTest.class, receiveTest.class,
		rollbackTest.class, sendTest.class, tickTest.class })
public class AllTests {

}
