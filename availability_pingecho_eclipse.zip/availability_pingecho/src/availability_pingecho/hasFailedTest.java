package availability_pingecho;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class hasFailedTest {
	private pingecho machine;
	
	@Before
	public void setUp() {
		machine = new pingecho();	
	}

    @After
    public void tearDown() {
            //
    }

    // hasFailed is enabled when time = 0 after the system beats
	@Test
	public void hasFailed_test_01() {
		// we make the system beat first 
		send s = new send(machine);
		assertTrue(s.guard_send());
		s.run_send();
		// the clock ticks until the receiver runs out of time
		tick t = new tick(machine);
		assertTrue(t.guard_tick());
		while(t.guard_tick()) {
			t.run_tick();
		}
		assertTrue(machine.get_time()==0);
		hasFailed hf = new hasFailed(machine);
		assertTrue(hf.guard_hasFailed());
	}


    // system cannot fail if it hasn't run out of time first
	@Test
	public void hasFailed_test_02() {
		// we make the system beat first 
		send s = new send(machine);
		assertTrue(s.guard_send());
		s.run_send();
		hasFailed hf = new hasFailed(machine);
		assertFalse(hf.guard_hasFailed());	
	}
	
	/*
	after hasFailed enabled
	 ( 
		always rollback enabled
	  )
	  */
	@Test
	public void hasFailed_test_inv4() {
    	machine.set_time(0);
    	machine.set_ping(true);
    	//
		hasFailed  hf = new hasFailed(machine);
		assertTrue(hf.guard_hasFailed());
		rollback rb = new rollback(machine);
		assertTrue(rb.guard_rollback());
	}
	
	/*
	 after hasFailed enabled
	 ( 
		always send disabled
			unless rollback executed
	  )
	  */

	@Test
	public void hasFailed_test_inv5() {
    	machine.set_time(0);
    	machine.set_ping(true);
    	//
		hasFailed  hf = new hasFailed(machine);
		assertTrue(hf.guard_hasFailed());
		send s = new send(machine);
		assertFalse(s.guard_send());
		//
		rollback rb = new rollback(machine);
		assertTrue(rb.guard_rollback());
		rb.run_rollback();
		assertTrue(s.guard_send());
	}

}
