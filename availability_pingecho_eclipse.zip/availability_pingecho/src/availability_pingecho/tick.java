package availability_pingecho;

import eventb_prelude.*;
import Util.Utilities;

public class tick extends Thread{
	/*@ spec_public */ private pingecho machine; // reference to the machine 

	/*@ public normal_behavior
		requires true;
		assignable \everything;
		ensures this.machine == m; */
	public tick(pingecho m) {
		this.machine = m;
	}

	/*@ public normal_behavior
		requires true;
 		assignable \nothing;
		ensures \result <==> (machine.get_time()).compareTo(new Integer(0)) > 0; */
	public /*@ pure */ boolean guard_tick() {
		return (machine.get_time()).compareTo(new Integer(0)) > 0;
	}

	/*@ public normal_behavior
		requires guard_tick();
		assignable machine.time, machine.send_enabled, machine.receive_enabled, machine.tick_enabled, machine.rollback_enabled, machine.hasFailed_enabled, machine.fail_enabled, machine.send_executed, machine.receive_executed, machine.tick_executed, machine.rollback_executed, machine.fail_executed;
		ensures guard_tick() &&  machine.get_time() == \old(new Integer(machine.get_time() - 1)) &&  machine.get_send_enabled() == \old((machine.get_ping().equals(false))) &&  machine.get_receive_enabled() == \old((machine.get_ping().equals(true) && (new Integer(machine.get_time() - 1)).compareTo(0) > 0)) &&  machine.get_tick_enabled() == \old(((new Integer(machine.get_time() - 1)).compareTo(0) > 0)) &&  machine.get_rollback_enabled() == \old(true) &&  machine.get_hasFailed_enabled() == \old((machine.get_ping().equals(true) && new Integer(machine.get_time() - 1).equals(0))) &&  machine.get_fail_enabled() == \old(true) &&  machine.get_send_executed() == \old(false) &&  machine.get_receive_executed() == \old(false) &&  machine.get_tick_executed() == \old(true) &&  machine.get_rollback_executed() == \old(false) &&  machine.get_fail_executed() == \old(false); 
	 also
		requires !guard_tick();
		assignable \nothing;
		ensures true; */
	public void run_tick(){
		if(guard_tick()) {
			Integer time_tmp = machine.get_time();
			Boolean send_enabled_tmp = machine.get_send_enabled();
			Boolean receive_enabled_tmp = machine.get_receive_enabled();
			Boolean tick_enabled_tmp = machine.get_tick_enabled();
			Boolean rollback_enabled_tmp = machine.get_rollback_enabled();
			Boolean hasFailed_enabled_tmp = machine.get_hasFailed_enabled();
			Boolean fail_enabled_tmp = machine.get_fail_enabled();
			Boolean send_executed_tmp = machine.get_send_executed();
			Boolean receive_executed_tmp = machine.get_receive_executed();
			Boolean tick_executed_tmp = machine.get_tick_executed();
			Boolean rollback_executed_tmp = machine.get_rollback_executed();
			Boolean fail_executed_tmp = machine.get_fail_executed();

			machine.set_time(new Integer(time_tmp - 1));
			machine.set_send_enabled((machine.get_ping().equals(false)));
			machine.set_receive_enabled((machine.get_ping().equals(true) && (new Integer(time_tmp - 1)).compareTo(0) > 0));
			machine.set_tick_enabled(((new Integer(time_tmp - 1)).compareTo(0) > 0));
			machine.set_rollback_enabled(true);
			machine.set_hasFailed_enabled((machine.get_ping().equals(true) && new Integer(time_tmp - 1).equals(0)));
			machine.set_fail_enabled(true);
			machine.set_send_executed(false);
			machine.set_receive_executed(false);
			machine.set_tick_executed(true);
			machine.set_rollback_executed(false);
			machine.set_fail_executed(false);

			System.out.println("tick executed ");
		}
	}

	public void run() {
		while(true) {
			machine.lock.lock(); // start of critical section
			run_tick();
			machine.lock.unlock(); // end of critical section
		}
	}
}
