package availability_pingecho;

import static org.junit.Assert.*;

import org.junit.*;

public class sendTest {
	private pingecho machine;
	
	@Before
	public void setUp() {
		machine = new pingecho();	
	}

    @After
    public void tearDown() {
    	//
    }
    /*
    after send executed
    ( 
   	always receive enabled
   		unless hasFailed enabled, fail executed
     )
     */
    @Test
    public void send_test_inv1_a() {
    	send s = new send(machine);
    	assertTrue(s.guard_send());
    	s.run_send();
    	//
    	receive r = new receive(machine);
    	assertTrue(r.guard_receive());
    	r.run_receive();
    	//
    	fail f = new fail(machine);
    	assertTrue(f.guard_fail());
    	f.run_fail();
    	assertFalse(r.guard_receive());
    }
    
    @Test
    public void send_test_inv1_b() {
    	send s = new send(machine);
    	assertTrue(s.guard_send());
    	s.run_send();
    	//
    	receive r = new receive(machine);
    	assertTrue(r.guard_receive());
    	r.run_receive();
    	// 
    	machine.set_time(0);
    	machine.set_ping(true);
    	hasFailed hf = new hasFailed(machine);
    	assertTrue(hf.guard_hasFailed());
    	assertFalse(r.guard_receive());
    }
    
    /*
    after fail executed
    ( 
   	always hasFailed enabled
   		unless rollback executed
     )*/
    @Test
    public void send_test_inv2() {
    	machine.set_time(0);
    	machine.set_ping(true);
    	fail f = new fail(machine);
    	assertTrue(f.guard_fail());
    	f.run_fail();
    	//
    	hasFailed hf = new hasFailed(machine);
    	assertTrue(hf.guard_hasFailed());
    	//
    	rollback rb = new rollback(machine);
    	assertTrue(rb.guard_rollback());
    	rb.run_rollback();
    	assertFalse(hf.guard_hasFailed());
    }

    /*
     after send executed
    ( 
   	always send disabled
   		unless rollback executed, receive executed
     )*/
	@Test
	public void send_test_inv3() {
    	send s = new send(machine);
    	assertTrue(s.guard_send());
    	s.run_send();
    	assertFalse(s.guard_send());
    	//
    	rollback rb = new rollback(machine);
    	machine.set_time(0);
    	assertTrue(rb.guard_rollback());
    	rb.run_rollback();
    	assertTrue(s.guard_send());
	}


}
