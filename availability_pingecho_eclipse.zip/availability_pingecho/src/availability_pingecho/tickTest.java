package availability_pingecho;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class tickTest {
	private pingecho machine;
	
	@Before
	public void setUp() {
		machine = new pingecho();	
	}

    @After
    public void tearDown() {
            //
    }

    // ticking decreases the time by 1
    // ticking starts after sending
	@Test
	public void tick_test_01() {
		send s = new send(machine);
		s.run_send();
		tick t = new tick(machine);
		assertTrue(t.guard_tick());
		int a = machine.get_time();
		t.run_tick();
		int b = machine.get_time();
		assertTrue(a == b+1);
	}

}
