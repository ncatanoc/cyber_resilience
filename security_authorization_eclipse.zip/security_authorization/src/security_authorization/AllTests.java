package security_authorization;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ add_resourceTest.class, add_subjectTest.class,
		delete_resourceTest.class, grant_permissionTest.class,
		revoke_permissionTest.class })
public class AllTests {

}
