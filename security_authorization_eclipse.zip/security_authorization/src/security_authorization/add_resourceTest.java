package security_authorization;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import eventb_prelude.*;

public class add_resourceTest {
	private authorization machine;
	
	@Before
	public void setUp() {
		machine = new authorization();	
	}

    @After
    public void tearDown() {
            //
    }

    // the first part is similar to add_subject_test_01
    // then a second fresh resource r1 is added to the same subject s
	@Test
	public void add_resource_test_01() {
		// adding subject and resource first
		add_subject as = new add_subject(machine);
		assertTrue(machine.get_subjects().isEmpty());
		assertTrue(machine.get_resources().isEmpty());
		//
		Integer s = machine.SUBJECTS.choose();
		Integer r = machine.RESOURCES.choose();
		assertTrue(as.guard_add_subject(r, s));
		as.run_add_subject(r, s);
		assertTrue(machine.get_subjects().has(s));
		assertTrue(machine.get_resources().has(r));
		assertTrue(machine.get_perm().apply(s).apply(r).domain().contains(s));
		
		// adding a second resource to the same subject
		Integer r1 = machine.RESOURCES.difference(new BSet<Integer>(r)).choose();
		add_resource ar = new add_resource(machine);
		assertTrue(ar.guard_add_resource(r1, s));
		ar.run_add_resource(r1, s);
		assertTrue(machine.get_resources().has(r1));
		assertTrue(machine.get_perm().apply(s).apply(r).domain().contains(s));	
	}
	

	// it is not possible to add a resource r a second time to the same subject s
	@Test
	public void add_resource_test_02() {
		// adding subject s with resource r
		add_subject as = new add_subject(machine);
		Integer s = machine.SUBJECTS.choose();
		Integer r = machine.RESOURCES.choose();
		assertTrue(as.guard_add_subject(r, s));
		as.run_add_subject(r, s);
		
		// it is not possible to add r a second time
		add_resource ar = new add_resource(machine);
		assertFalse(ar.guard_add_resource(r, s));
	}
	

	// it is not possible to add a resource r a second time to another subject
	@Test
	public void add_resource_test_03() {
		// adding subject s with resource r
		add_subject as = new add_subject(machine);
		Integer s = machine.SUBJECTS.choose();
		Integer r = machine.RESOURCES.choose();
		assertTrue(as.guard_add_subject(r, s));
		as.run_add_subject(r, s);
		
		// it is not possible to add r a second time
		Integer s1 = machine.SUBJECTS.difference(new BSet<Integer>(s)).choose();
		assertFalse(as.guard_add_subject(r, s1));
	}

}
