package security_authorization;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import eventb_prelude.BSet;
import eventb_prelude.Pair;

public class revoke_permissionTest {
	private authorization machine;
	
	@Before
	public void setUp() {
		machine = new authorization();	
	}

    @After
    public void tearDown() {
            //
    }

    // we create subject s1 with resource r1, and subject s2 with resource r2
    // subject s1 then grants read permission over r1 to s2
	@Test
	public void revoke_permission_test_01() {
		// adding the first subject
		add_subject as = new add_subject(machine);
		Integer s1 = machine.SUBJECTS.choose();
		Integer r1 = machine.RESOURCES.choose();
		assertTrue(as.guard_add_subject(r1, s1));
		as.run_add_subject(r1, s1);

		// adding the second subject
		Integer s2 = machine.SUBJECTS.difference(new BSet<Integer>(s1)).choose();
		Integer r2 = machine.RESOURCES.difference(new BSet<Integer>(r1)).choose();
		assertTrue(as.guard_add_subject(r2, s2));
		as.run_add_subject(r2, s2);
		 
		// s1 (who owns r1) grants read permissions over r1 to s2
		grant_permission gp = new grant_permission(machine);
		assertTrue(gp.guard_grant_permission(r1, 2, s1, s2));
		gp.run_grant_permission(r1, 2, s1, s2); // 2 means read permission
		assertTrue(machine.get_perm().apply(s1).apply(r1).contains(new Pair<Integer,Integer>(s2,2)));
		// 
		
		// revoking the permission
		revoke_permission rp = new revoke_permission(machine);
		assertTrue(rp.guard_revoke_permission(r1, 2, s1, s2));
		rp.run_revoke_permission(r1, 2, s1, s2);
		assertFalse(machine.get_perm().apply(s1).apply(r1).contains(new Pair<Integer,Integer>(s2,2)));
		//
		
		// revoking non-existing permissions
		assertFalse(rp.guard_revoke_permission(r1, 2, s1, s2));
	}

}
