package security_authorization;

import eventb_prelude.*;
import Util.*;
//@ model import org.jmlspecs.models.JMLObjectSet;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class authorization{
	private int n_events = 6;
	private static final Integer max_integer = Utilities.max_integer;
	private static final Integer min_integer = Utilities.min_integer;
	private Thread[] events;
	public Lock lock = new ReentrantLock(true);


	/******Set definitions******/
	//@ public static constraint RESOURCES.equals(\old(RESOURCES)); 
	public static final BSet<Integer> RESOURCES = new Enumerated(min_integer,max_integer);

	//@ public static constraint SUBJECTS.equals(\old(SUBJECTS)); 
	public static final BSet<Integer> SUBJECTS = new Enumerated(min_integer,max_integer);
	
	public static final Enumerated PERM = new Enumerated(0,3);


	/******Constant definitions******/
	//@ public static constraint delete.equals(\old(delete)); 
	public static final Integer delete = 0;

	//@ public static constraint edit.equals(\old(edit)); 
	public static final Integer edit = 1;

	//@ public static constraint read.equals(\old(read)); 
	public static final Integer read = 2;

	//@ public static constraint share.equals(\old(share)); 
	public static final Integer share = 3;
	

	/******Axiom definitions******/
	/*@ public static invariant INT.instance.has(delete); */
	/*@ public static invariant INT.instance.has(edit); */
	/*@ public static invariant INT.instance.has(read); */
	/*@ public static invariant INT.instance.has(share); */


	/******Variable definitions******/
	/*@ spec_public */ private BRelation<Integer,BRelation<Integer,BRelation<Integer,Integer>>> perm;

	/*@ spec_public */ private BSet<Integer> resources;

	/*@ spec_public */ private BSet<Integer> subjects;




	/******Invariant definition******/
	/*@ public invariant
		subjects.isSubset(SUBJECTS) &&
		resources.isSubset(RESOURCES) &&
		 perm.domain().equals(subjects) && perm.range().isSubset(BRelation.cross(resources,BRelation.cross(subjects,INT.instance))) && perm.isaFunction() && BRelation.cross(subjects,BRelation.cross(resources,BRelation.cross(subjects,INT.instance))).has(perm) &&
		 (\forall Integer u;((subjects.has(u)) ==> (!perm.apply(u).equals(BSet.EMPTY)))) &&
		 (\forall Integer s1;  (\forall Integer s2;((subjects.has(s1) && subjects.has(s2) && !s1.equals(s2)) ==> ((perm.apply(s1).domain().intersection(perm.apply(s2).domain())).equals(BSet.EMPTY))))) &&
		 (\forall Integer s;  (\forall Integer r;  (\forall Integer p;((subjects.has(s) && perm.apply(s).domain().has(r) && INT.instance.has(p)) ==> (perm.apply(s).apply(r).has(new Pair<Integer,Integer>(s,p))))))) &&
		 (\forall Integer r;((resources.has(r)) ==> ( (\exists Integer s;subjects.has(s) && perm.apply(s).domain().has(r))))); */


	/******Getter and Mutator methods definition******/
	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.perm;*/
	public /*@ pure */ BRelation<Integer,BRelation<Integer,BRelation<Integer,Integer>>> get_perm(){
		return this.perm;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.perm;
	    ensures this.perm == perm;*/
	public void set_perm(BRelation<Integer,BRelation<Integer,BRelation<Integer,Integer>>> perm){
		this.perm = perm;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.subjects;*/
	public /*@ pure */ BSet<Integer> get_subjects(){
		return this.subjects;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.subjects;
	    ensures this.subjects == subjects;*/
	public void set_subjects(BSet<Integer> subjects){
		this.subjects = subjects;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.resources;*/
	public /*@ pure */ BSet<Integer> get_resources(){
		return this.resources;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.resources;
	    ensures this.resources == resources;*/
	public void set_resources(BSet<Integer> resources){
		this.resources = resources;
	}



	/*@ public normal_behavior
	    requires true;
	    assignable \everything;
	    ensures
		subjects.isEmpty() &&
		resources.isEmpty() &&
		perm.isEmpty();*/
	public authorization(){
		subjects = new BSet<Integer>();
		resources = new BSet<Integer>();
		perm = new BRelation<Integer,BRelation<Integer,BRelation<Integer,Integer>>>();

		/*events = new Thread[n_events];
		events[0] = new add_subject(this);
		events[1] = new revoke_permission(this);
		events[3] = new add_resource(this);
		events[4] = new delete_resource(this);
		events[5] = new grant_permission(this);

		for (int i = 0; i < n_events;i++){
			events[i].start();
		}*/
	}
}