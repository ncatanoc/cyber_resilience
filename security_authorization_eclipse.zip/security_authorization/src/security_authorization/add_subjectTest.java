package security_authorization;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;


import eventb_prelude.*;


public class add_subjectTest {
	private authorization machine;
	
	@Before
	public void setUp() {
		machine = new authorization();	
	}

    @After
    public void tearDown() {
            //
    }

    // subjects and resources are initially empty
    // a fresh subject s is created with all the permissions over a fresh resource r
	@Test
	public void add_subject_test_01() {
		add_subject as = new add_subject(machine);
		assertTrue(machine.get_subjects().isEmpty());
		assertTrue(machine.get_resources().isEmpty());
		//
		Integer s = machine.SUBJECTS.choose();
		Integer r = machine.RESOURCES.choose();
		assertTrue(as.guard_add_subject(r, s));
		as.run_add_subject(r, s);
		assertTrue(machine.get_subjects().has(s));
		assertTrue(machine.get_resources().has(r));
		assertTrue(machine.get_perm().apply(s).apply(r).domain().contains(s));
	}
	
	// the same subject cannot added a second time
	@Test
	public void add_subject_test_02() {
		add_subject as = new add_subject(machine);
		Integer s = machine.SUBJECTS.choose();
		Integer r = machine.RESOURCES.choose();
		assertTrue(as.guard_add_subject(r, s));
		as.run_add_subject(r, s);
		//
		Integer r1 = machine.RESOURCES.difference(new BSet<Integer>(r)).choose();
		assertFalse(as.guard_add_subject(r1, s));
	}

}
