package security_authorization; 

import eventb_prelude.*;
import Util.Utilities;

public class delete_resource extends Thread{
	/*@ spec_public */ private authorization machine; // reference to the machine 

	/*@ public normal_behavior
		requires true;
		assignable \everything;
		ensures this.machine == m; */
	public delete_resource(authorization m) {
		this.machine = m;
	}

	/*@ public normal_behavior
		requires true;
 		assignable \nothing;
		ensures \result <==> (machine.get_subjects().has(u) && machine.get_subjects().has(ow) && machine.get_perm().apply(ow).domain().has(d) && machine.get_perm().apply(ow).apply(d).has(new Pair<Integer,Integer>(u,machine.delete)) && !machine.get_perm().apply(ow).domainSubtraction(new BSet<Integer>(d)).equals(BSet.EMPTY)); */
	public /*@ pure */ boolean guard_delete_resource( Integer d, Integer ow, Integer u) {		
		return (machine.get_subjects().has(u) && machine.get_subjects().has(ow) && machine.get_perm().apply(ow).domain().has(d) && machine.get_perm().apply(ow).apply(d).has(new Pair<Integer,Integer>(u,machine.delete)) && !machine.get_perm().apply(ow).domainSubtraction(new BSet<Integer>(d)).equals(BSet.EMPTY));
	}

	/*@ public normal_behavior
		requires guard_delete_resource(d,ow,u);
		assignable machine.perm, machine.resources;
		ensures guard_delete_resource(d,ow,u) &&  machine.get_perm().equals(\old((machine.get_perm().override(new BRelation<Integer,BRelation<Integer,BRelation<Integer,Integer>>>(new Pair<Integer,BRelation<Integer,BRelation<Integer,Integer>>>(ow,machine.get_perm().apply(ow).domainSubtraction(new BSet<Integer>(d)))))))) &&  machine.get_resources().equals(\old(machine.get_resources().difference(new BSet<Integer>(d)))); 
	 also
		requires !guard_delete_resource(d,ow,u);
		assignable \nothing;
		ensures true; */
	public void run_delete_resource( Integer d, Integer ow, Integer u){
		if(guard_delete_resource(d,ow,u)) {
			BRelation<Integer,BRelation<Integer,BRelation<Integer,Integer>>> perm_tmp = machine.get_perm();
			BSet<Integer> resources_tmp = machine.get_resources();

			machine.set_perm((perm_tmp.override(new BRelation<Integer,BRelation<Integer,BRelation<Integer,Integer>>>(new Pair<Integer,BRelation<Integer,BRelation<Integer,Integer>>>(ow,perm_tmp.apply(ow).domainSubtraction(new BSet<Integer>(d)))))));
			machine.set_resources(resources_tmp.difference(new BSet<Integer>(d)));

			System.out.println("delete_resource executed d: " + d + " ow: " + ow + " u: " + u + " ");
		}
	}

	public void run() {
		while(true) {
			Integer d = Utilities.someVal(new BSet<Integer>((new Enumerated(1,Utilities.max_integer))));
			Integer ow = Utilities.someVal(new BSet<Integer>((new Enumerated(1,Utilities.max_integer))));
			Integer u = Utilities.someVal(new BSet<Integer>((new Enumerated(1,Utilities.max_integer))));
			machine.lock.lock(); // start of critical section
			run_delete_resource(d,ow,u);
			machine.lock.unlock(); // end of critical section
		}
	}
}
