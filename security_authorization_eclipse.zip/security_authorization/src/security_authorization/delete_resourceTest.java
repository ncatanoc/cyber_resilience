package security_authorization;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import eventb_prelude.*;

public class delete_resourceTest {
	private authorization machine;
	
	@Before
	public void setUp() {
		machine = new authorization();	
	}

    @After
    public void tearDown() {
            //
    }

    // similar to resource_test_01, but we add a second resource and 
    // then delete the first one
	@Test
	public void delete_resource_test_01() {
		// adding subject and resource first
		add_subject as = new add_subject(machine);
		assertTrue(machine.get_subjects().isEmpty());
		assertTrue(machine.get_resources().isEmpty());
		//
		Integer s = machine.SUBJECTS.choose();
		Integer r = machine.RESOURCES.choose();
		assertTrue(as.guard_add_subject(r, s));
		as.run_add_subject(r, s);
		assertTrue(machine.get_subjects().has(s));
		assertTrue(machine.get_resources().has(r));
		assertTrue(machine.get_perm().apply(s).apply(r).domain().contains(s));
		
		// adding a second resource to the same subject
		Integer r1 = machine.RESOURCES.difference(new BSet<Integer>(r)).choose();
		add_resource ar = new add_resource(machine);
		assertTrue(ar.guard_add_resource(r1, s));
		ar.run_add_resource(r1, s);
		assertTrue(machine.get_resources().has(r1));
		assertTrue(machine.get_perm().apply(s).apply(r).domain().contains(s));
		
		// deleting the resource
		delete_resource dr = new delete_resource(machine);
		assertTrue(dr.guard_delete_resource(r, s, s));
		dr.run_delete_resource(r, s, s);
		assertFalse(machine.get_resources().has(r));
	}
	

}
