package availability_heartbeat;


public class HeartBeatThreaded extends HeartBeat {
	
	public HeartBeatThreaded() {
		events = new Thread[n_events];
		events[0] = new hasFailed(this);
		events[1] = new rollback(this);
		//events[6] = new receive(this); // receive is embedded within the Kinetic machine
		events[2] = new skip(this);
		events[3] = new fail(this);
		events[4] = new tick(this);
		//events[5] = new send(this); // send is embedded within the Kinetic machine
		events[5] = new skip(this);

		for (int i = 0; i < n_events;i++){
			events[i].start();
		}
	}
	
	/*public static void main(String args[]){
		HeartBeatThreaded hb_machine = new HeartBeatThreaded();	
	}*/

}
