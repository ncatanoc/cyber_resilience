package availability_heartbeat;

import eventb_prelude.*;
import Util.Utilities;

public class send extends Thread{
	/*@ spec_public */ private HeartBeat machine; // reference to the machine 

	/*@ public normal_behavior
		requires true;
		assignable \everything;
		ensures this.machine == m; */
	public send(HeartBeat m) {
		this.machine = m;
	}

	/*@ public normal_behavior
		requires true;
 		assignable \nothing;
		ensures \result <==> machine.get_beat().equals(false); */
	public /*@ pure */ boolean guard_send() {
		return machine.get_beat().equals(false);
	}

	/*@ public normal_behavior
		requires guard_send();
		assignable machine.beat, machine.time, machine.send_enabled, machine.receive_enabled, machine.tick_enabled, machine.rollback_enabled, machine.hasFailed_enabled, machine.fail_enabled, machine.send_executed, machine.receive_executed, machine.rollback_executed, machine.fail_executed;
		ensures guard_send() &&  machine.get_beat() == \old(true) &&  machine.get_time() == \old(machine.Tslot) &&  machine.get_send_enabled() == \old(false) &&  machine.get_receive_enabled() == \old(true) &&  machine.get_tick_enabled() == \old(true) &&  machine.get_rollback_enabled() == \old(true) &&  machine.get_hasFailed_enabled() == \old(false) &&  machine.get_fail_enabled() == \old(true) &&  machine.get_send_executed() == \old(true) &&  machine.get_receive_executed() == \old(false) &&  machine.get_rollback_executed() == \old(false) &&  machine.get_fail_executed() == \old(false); 
	 also
		requires !guard_send();
		assignable \nothing;
		ensures true; */
	public void run_send(){
		if(guard_send()) {
			Boolean beat_tmp = machine.get_beat();
			Integer time_tmp = machine.get_time();
			Boolean send_enabled_tmp = machine.get_send_enabled();
			Boolean receive_enabled_tmp = machine.get_receive_enabled();
			Boolean tick_enabled_tmp = machine.get_tick_enabled();
			Boolean rollback_enabled_tmp = machine.get_rollback_enabled();
			Boolean hasFailed_enabled_tmp = machine.get_hasFailed_enabled();
			Boolean fail_enabled_tmp = machine.get_fail_enabled();
			Boolean send_executed_tmp = machine.get_send_executed();
			Boolean receive_executed_tmp = machine.get_receive_executed();
			Boolean rollback_executed_tmp = machine.get_rollback_executed();
			Boolean fail_executed_tmp = machine.get_fail_executed();

			machine.set_beat(true);
			machine.set_time(machine.Tslot);
			machine.set_send_enabled(false);
			machine.set_receive_enabled(true);
			machine.set_tick_enabled(true);
			machine.set_rollback_enabled(true);
			machine.set_hasFailed_enabled(false);
			machine.set_fail_enabled(true);
			machine.set_send_executed(true);
			machine.set_receive_executed(false);
			machine.set_rollback_executed(false);
			machine.set_fail_executed(false);

			System.out.println("send executed ");
		}
	}

	public void run() {
		while(true) {
			machine.lock.lock(); // start of critical section
			run_send();
			machine.lock.unlock(); // end of critical section
		}
	}
}
