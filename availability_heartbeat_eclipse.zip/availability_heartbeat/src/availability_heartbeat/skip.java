package availability_heartbeat;

import eventb_prelude.*;
import Util.Utilities;

public class skip extends Thread{
	/*@ spec_public */ private HeartBeat machine; // reference to the machine 

	public skip(HeartBeat m) {
		this.machine = m;
	}

	public /*@ pure */ boolean guard_skip() {
		return true;
	}

	public void run_skip(){
		if(guard_skip()) {
			System.out.println("skip executed ");
		}
	}

	public void run() {
		while(true) {
			machine.lock.lock(); // start of critical section
			run_skip();
			machine.lock.unlock(); // end of critical section
		}
	}
}
