package availability_heartbeat;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class receiveTest {
	private HeartBeat machine;
	
	@Before
	public void setUp() {
		machine = new HeartBeat();	
	}

    @After
    public void tearDown() {
            //
    }


    // the system can acknowledge the beat right after is sent
	@Test
	public void receive_test_01() {
		// the system beats
		send s = new send(machine);
		assertTrue(s.guard_send());
		s.run_send();
		assertTrue(machine.get_beat());
		// the beat is received
		receive r = new receive(machine);
		assertTrue(r.guard_receive());
		r.run_receive();
		assertFalse(machine.get_beat());	
	}
	
	// receive enables send
	@Test
	public void receive_test_02() {		
		// the system beats
		send s = new send(machine);
		assertTrue(s.guard_send());
		s.run_send();
		assertTrue(machine.get_beat());
		// the beat is received
		receive r = new receive(machine);
		assertTrue(r.guard_receive());
		r.run_receive();
		assertFalse(machine.get_beat());
		//
		
	}

}
