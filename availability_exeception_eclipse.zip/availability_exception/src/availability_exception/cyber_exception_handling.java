package availability_exception;

import eventb_prelude.*;
import Util.Utilities;

public class cyber_exception_handling extends Thread{
	/*@ spec_public */ private exception machine; // reference to the machine 

	/*@ public normal_behavior
		requires true;
		assignable \everything;
		ensures this.machine == m; */
	public cyber_exception_handling(exception m) {
		this.machine = m;
	}

	/*@ public normal_behavior
		requires true;
 		assignable \nothing;
		ensures \result <==> machine.get_cyberevent().equals(true); */
	public /*@ pure */ boolean guard_cyber_exception_handling() {
		return machine.get_cyberevent().equals(true);
	}

	/*@ public normal_behavior
		requires guard_cyber_exception_handling();
		assignable machine.cyberevent, machine.cyber_exception_handling_enabled;
		ensures guard_cyber_exception_handling() &&  machine.get_cyberevent() == \old(false) &&  machine.get_cyber_exception_handling_enabled() == \old(false); 
	 also
		requires !guard_cyber_exception_handling();
		assignable \nothing;
		ensures true; */
	public void run_cyber_exception_handling(){
		if(guard_cyber_exception_handling()) {
			Boolean cyberevent_tmp = machine.get_cyberevent();
			Boolean cyber_exception_handling_enabled_tmp = machine.get_cyber_exception_handling_enabled();

			machine.set_cyberevent(false);
			machine.set_cyber_exception_handling_enabled(false);

			System.out.println("cyber_exception_handling executed ");
		}
	}

	public void run() {
		while(true) {
			machine.lock.lock(); // start of critical section
			run_cyber_exception_handling();
			machine.lock.unlock(); // end of critical section
		}
	}
}
