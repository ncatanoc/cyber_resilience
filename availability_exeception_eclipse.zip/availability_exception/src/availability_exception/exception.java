package availability_exception;

import eventb_prelude.*;
import Util.*;
//@ model import org.jmlspecs.models.JMLObjectSet;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class exception{
	private int n_events = 2;
	private static final Integer max_integer = Utilities.max_integer;
	private static final Integer min_integer = Utilities.min_integer;
	private Thread[] events;
	public Lock lock = new ReentrantLock(true);


	/******Set definitions******/

	/******Constant definitions******/


	/******Axiom definitions******/


	/******Variable definitions******/
	/*@ spec_public */ private Boolean cyber_exception_enabled;

	/*@ spec_public */ private Boolean cyber_exception_executed;

	/*@ spec_public */ private Boolean cyber_exception_handling_enabled;

	/*@ spec_public */ private Boolean cyber_exception_handling_executed;

	/*@ spec_public */ private Boolean cyberevent;

	/*@ spec_public */ private Boolean inv1;




	/******Invariant definition******/
	/*@ public invariant
		BOOL.instance.has(cyberevent) &&
		BOOL.instance.has(cyber_exception_enabled) &&
		BOOL.instance.has(cyber_exception_executed) &&
		BOOL.instance.has(cyber_exception_handling_enabled) &&
		BOOL.instance.has(cyber_exception_handling_executed) &&
		cyber_exception_handling_enabled.equals((cyberevent.equals(true))) &&
		cyber_exception_enabled.equals(true) &&
		BOOL.instance.has(inv1) &&
		inv1.equals(true) &&
		inv1.equals((((cyber_exception_executed.equals(true)) ==> (((cyber_exception_handling_executed.equals(true)) ==> (cyber_exception_handling_enabled.equals(false))) || cyber_exception_handling_enabled.equals(true))))); */


	/******Getter and Mutator methods definition******/
	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.cyber_exception_enabled;*/
	public /*@ pure */ Boolean get_cyber_exception_enabled(){
		return this.cyber_exception_enabled;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.cyber_exception_enabled;
	    ensures this.cyber_exception_enabled == cyber_exception_enabled;*/
	public void set_cyber_exception_enabled(Boolean cyber_exception_enabled){
		this.cyber_exception_enabled = cyber_exception_enabled;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.cyber_exception_handling_executed;*/
	public /*@ pure */ Boolean get_cyber_exception_handling_executed(){
		return this.cyber_exception_handling_executed;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.cyber_exception_handling_executed;
	    ensures this.cyber_exception_handling_executed == cyber_exception_handling_executed;*/
	public void set_cyber_exception_handling_executed(Boolean cyber_exception_handling_executed){
		this.cyber_exception_handling_executed = cyber_exception_handling_executed;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.inv1;*/
	public /*@ pure */ Boolean get_inv1(){
		return this.inv1;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.inv1;
	    ensures this.inv1 == inv1;*/
	public void set_inv1(Boolean inv1){
		this.inv1 = inv1;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.cyber_exception_executed;*/
	public /*@ pure */ Boolean get_cyber_exception_executed(){
		return this.cyber_exception_executed;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.cyber_exception_executed;
	    ensures this.cyber_exception_executed == cyber_exception_executed;*/
	public void set_cyber_exception_executed(Boolean cyber_exception_executed){
		this.cyber_exception_executed = cyber_exception_executed;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.cyberevent;*/
	public /*@ pure */ Boolean get_cyberevent(){
		return this.cyberevent;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.cyberevent;
	    ensures this.cyberevent == cyberevent;*/
	public void set_cyberevent(Boolean cyberevent){
		this.cyberevent = cyberevent;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.cyber_exception_handling_enabled;*/
	public /*@ pure */ Boolean get_cyber_exception_handling_enabled(){
		return this.cyber_exception_handling_enabled;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.cyber_exception_handling_enabled;
	    ensures this.cyber_exception_handling_enabled == cyber_exception_handling_enabled;*/
	public void set_cyber_exception_handling_enabled(Boolean cyber_exception_handling_enabled){
		this.cyber_exception_handling_enabled = cyber_exception_handling_enabled;
	}



	/*@ public normal_behavior
	    requires true;
	    assignable \everything;
	    ensures
		cyberevent == false &&
		cyber_exception_enabled == true &&
		cyber_exception_executed == false &&
		cyber_exception_handling_enabled == false &&
		cyber_exception_handling_executed == false &&
		inv1 == true;*/
	public exception(){
		cyberevent = false;
		cyber_exception_enabled = true;
		cyber_exception_executed = false;
		cyber_exception_handling_enabled = false;
		cyber_exception_handling_executed = false;
		inv1 = true;

		/*events = new Thread[n_events];
		events[0] = new cyber_exception_handling(this);
		events[1] = new cyber_exception(this);

		for (int i = 0; i < n_events;i++){
			events[i].start();
		}*/
	}
}