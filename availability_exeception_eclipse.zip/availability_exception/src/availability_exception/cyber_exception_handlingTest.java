package availability_exception;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class cyber_exception_handlingTest {
	private exception machine;
	
	@Before
	public void setUp() {
		machine = new exception();	
	}

    @After
    public void tearDown() {
            //
    }

    // any cyber-exception is handled by the system
	@Test
	public void cyber_exception_handling_test_01() {
		cyber_exception ce = new cyber_exception(machine);
		assertTrue(ce.guard_cyber_exception());
		ce.run_cyber_exception();
		//
		cyber_exception_handling ceh = new cyber_exception_handling(machine);
		assertTrue(ceh.guard_cyber_exception_handling());
		ceh.run_cyber_exception_handling();
		assertFalse(machine.get_cyberevent());
	}

}
