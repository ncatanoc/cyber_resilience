package availability_exception;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ cyber_exception_handlingTest.class, cyber_exceptionTest.class })
public class AllTests {

}
