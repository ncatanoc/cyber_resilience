package availability_exception;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class cyber_exceptionTest {
	private exception machine;
	
	@Before
	public void setUp() {
		machine = new exception();	
	}

    @After
    public void tearDown() {
            //
    }

	@Test
	public void cyber_exception_test_01() {
		cyber_exception ce = new cyber_exception(machine);
		assertTrue(ce.guard_cyber_exception());
		ce.run_cyber_exception();
		assertTrue(machine.get_cyberevent());
	}
	
	/*
	after cyber_exception executed
	 ( 
		always cyber_exception_handling enabled
			unless cyber_exception_handling executed
	  )
	  */
	
	@Test
	public void cyber_exception_test_inv1() {
		cyber_exception ce = new cyber_exception(machine);
		assertTrue(ce.guard_cyber_exception());
		ce.run_cyber_exception();
		//
		cyber_exception_handling ceh = new cyber_exception_handling(machine);
		assertTrue(ceh.guard_cyber_exception_handling());
		//
		ceh.run_cyber_exception_handling();
		assertFalse(ceh.guard_cyber_exception_handling());
	}

}
