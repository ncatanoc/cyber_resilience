package availability_exception;

import eventb_prelude.*;
import Util.Utilities;

public class cyber_exception extends Thread{
	/*@ spec_public */ private exception machine; // reference to the machine 

	/*@ public normal_behavior
		requires true;
		assignable \everything;
		ensures this.machine == m; */
	public cyber_exception(exception m) {
		this.machine = m;
	}

	/*@ public normal_behavior
		requires true;
 		assignable \nothing;
		ensures \result <==> true; */
	public /*@ pure */ boolean guard_cyber_exception() {
		return true;
	}

	/*@ public normal_behavior
		requires guard_cyber_exception();
		assignable machine.cyberevent, machine.cyber_exception_handling_enabled, machine.cyber_exception_handling_executed;
		ensures guard_cyber_exception() &&  machine.get_cyberevent() == \old(true) &&  machine.get_cyber_exception_handling_enabled() == \old(true) &&  machine.get_cyber_exception_handling_executed() == \old(false); 
	 also
		requires !guard_cyber_exception();
		assignable \nothing;
		ensures true; */
	public void run_cyber_exception(){
		if(guard_cyber_exception()) {
			Boolean cyberevent_tmp = machine.get_cyberevent();
			Boolean cyber_exception_handling_enabled_tmp = machine.get_cyber_exception_handling_enabled();
			Boolean cyber_exception_handling_executed_tmp = machine.get_cyber_exception_handling_executed();

			machine.set_cyberevent(true);
			machine.set_cyber_exception_handling_enabled(true);
			machine.set_cyber_exception_handling_executed(false);

			System.out.println("cyber_exception executed ");
		}
	}

	public void run() {
		while(true) {
			machine.lock.lock(); // start of critical section
			run_cyber_exception();
			machine.lock.unlock(); // end of critical section
		}
	}
}
