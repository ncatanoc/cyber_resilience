package performance_limit_epriority_multi_threaded;

import eventb_prelude.*;
import Util.*;
//@ model import org.jmlspecs.models.JMLObjectSet;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class performance_limit_epriority{
	private int n_events = 5;
	private static final Integer max_integer = Utilities.max_integer;
	private static final Integer min_integer = Utilities.min_integer;
	private Thread[] events;
	public Lock lock = new ReentrantLock(true);


	/******Set definitions******/
	//@ public static constraint TASKS.equals(\old(TASKS)); 
	public static final BSet<Integer> TASKS = new Enumerated(min_integer,max_integer);


	/******Constant definitions******/


	/******Axiom definitions******/


	/******Variable definitions******/
	/*@ spec_public */ private Boolean inv1;

	/*@ spec_public */ private Boolean receive_task_enabled;

	/*@ spec_public */ private Boolean receive_task_executed;

	/*@ spec_public */ private Integer receivedtask;

	/*@ spec_public */ private BSet<Integer> receivedtasks;

	/*@ spec_public */ private BRelation<Integer,Integer> receivepriority;

	/*@ spec_public */ private Boolean run_task_enabled;

	/*@ spec_public */ private Boolean run_task_executed;

	/*@ spec_public */ private Boolean send_task_enabled;

	/*@ spec_public */ private Boolean send_task_executed;

	/*@ spec_public */ private BRelation<Integer,Integer> sendpriority;

	/*@ spec_public */ private Integer senttask;

	/*@ spec_public */ private BSet<Integer> senttasks;

	/*@ spec_public */ private BSet<Integer> tasks;




	/******Invariant definition******/
	/*@ public invariant
		tasks.isSubset(TASKS) &&
		senttasks.isSubset(tasks) &&
		receivedtasks.isSubset(tasks) &&
		tasks.equals((senttasks.union(receivedtasks))) &&
		 sendpriority.domain().equals(senttasks) && sendpriority.range().isSubset(NAT.instance) && sendpriority.isaFunction() && BRelation.cross(senttasks,NAT.instance).has(sendpriority) &&
		 receivepriority.domain().equals(receivedtasks) && receivepriority.range().isSubset(NAT.instance) && receivepriority.isaFunction() && BRelation.cross(receivedtasks,NAT.instance).has(receivepriority) &&
		BOOL.instance.has(send_task_enabled) &&
		TASKS.has(senttask) &&
		BOOL.instance.has(receive_task_enabled) &&
		TASKS.has(receivedtask) &&
		BOOL.instance.has(send_task_executed) &&
		BOOL.instance.has(receive_task_executed) &&
		BOOL.instance.has(run_task_executed) &&
		BOOL.instance.has(send_task_enabled) &&
		BOOL.instance.has(receive_task_enabled) &&
		BOOL.instance.has(run_task_enabled) &&
		BOOL.instance.has(inv1) &&
		inv1.equals(true) &&
		inv1.equals((((send_task_executed.equals(true)) ==> (((receive_task_executed.equals(true)) ==> (receive_task_enabled.equals(false))) || receive_task_enabled.equals(true))))); */


	/******Getter and Mutator methods definition******/
	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.receivepriority;*/
	public /*@ pure */ BRelation<Integer,Integer> get_receivepriority(){
		return this.receivepriority;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.receivepriority;
	    ensures this.receivepriority == receivepriority;*/
	public void set_receivepriority(BRelation<Integer,Integer> receivepriority){
		this.receivepriority = receivepriority;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.receive_task_enabled;*/
	public /*@ pure */ Boolean get_receive_task_enabled(){
		return this.receive_task_enabled;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.receive_task_enabled;
	    ensures this.receive_task_enabled == receive_task_enabled;*/
	public void set_receive_task_enabled(Boolean receive_task_enabled){
		this.receive_task_enabled = receive_task_enabled;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.receivedtasks;*/
	public /*@ pure */ BSet<Integer> get_receivedtasks(){
		return this.receivedtasks;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.receivedtasks;
	    ensures this.receivedtasks == receivedtasks;*/
	public void set_receivedtasks(BSet<Integer> receivedtasks){
		this.receivedtasks = receivedtasks;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.receivedtask;*/
	public /*@ pure */ Integer get_receivedtask(){
		return this.receivedtask;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.receivedtask;
	    ensures this.receivedtask == receivedtask;*/
	public void set_receivedtask(Integer receivedtask){
		this.receivedtask = receivedtask;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.inv1;*/
	public /*@ pure */ Boolean get_inv1(){
		return this.inv1;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.inv1;
	    ensures this.inv1 == inv1;*/
	public void set_inv1(Boolean inv1){
		this.inv1 = inv1;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.senttasks;*/
	public /*@ pure */ BSet<Integer> get_senttasks(){
		return this.senttasks;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.senttasks;
	    ensures this.senttasks == senttasks;*/
	public void set_senttasks(BSet<Integer> senttasks){
		this.senttasks = senttasks;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.send_task_executed;*/
	public /*@ pure */ Boolean get_send_task_executed(){
		return this.send_task_executed;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.send_task_executed;
	    ensures this.send_task_executed == send_task_executed;*/
	public void set_send_task_executed(Boolean send_task_executed){
		this.send_task_executed = send_task_executed;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.receive_task_executed;*/
	public /*@ pure */ Boolean get_receive_task_executed(){
		return this.receive_task_executed;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.receive_task_executed;
	    ensures this.receive_task_executed == receive_task_executed;*/
	public void set_receive_task_executed(Boolean receive_task_executed){
		this.receive_task_executed = receive_task_executed;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.sendpriority;*/
	public /*@ pure */ BRelation<Integer,Integer> get_sendpriority(){
		return this.sendpriority;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.sendpriority;
	    ensures this.sendpriority == sendpriority;*/
	public void set_sendpriority(BRelation<Integer,Integer> sendpriority){
		this.sendpriority = sendpriority;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.senttask;*/
	public /*@ pure */ Integer get_senttask(){
		return this.senttask;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.senttask;
	    ensures this.senttask == senttask;*/
	public void set_senttask(Integer senttask){
		this.senttask = senttask;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.run_task_executed;*/
	public /*@ pure */ Boolean get_run_task_executed(){
		return this.run_task_executed;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.run_task_executed;
	    ensures this.run_task_executed == run_task_executed;*/
	public void set_run_task_executed(Boolean run_task_executed){
		this.run_task_executed = run_task_executed;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.run_task_enabled;*/
	public /*@ pure */ Boolean get_run_task_enabled(){
		return this.run_task_enabled;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.run_task_enabled;
	    ensures this.run_task_enabled == run_task_enabled;*/
	public void set_run_task_enabled(Boolean run_task_enabled){
		this.run_task_enabled = run_task_enabled;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.send_task_enabled;*/
	public /*@ pure */ Boolean get_send_task_enabled(){
		return this.send_task_enabled;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.send_task_enabled;
	    ensures this.send_task_enabled == send_task_enabled;*/
	public void set_send_task_enabled(Boolean send_task_enabled){
		this.send_task_enabled = send_task_enabled;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.tasks;*/
	public /*@ pure */ BSet<Integer> get_tasks(){
		return this.tasks;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.tasks;
	    ensures this.tasks == tasks;*/
	public void set_tasks(BSet<Integer> tasks){
		this.tasks = tasks;
	}



	/*@ public normal_behavior
	    requires true;
	    assignable \everything;
	    ensures
		tasks.isEmpty() &&
		senttasks.isEmpty() &&
		receivedtasks.isEmpty() &&
		send_task_executed == false &&
		receive_task_executed == false &&
		run_task_executed == false &&
		send_task_enabled == false &&
		receive_task_enabled == false &&
		run_task_enabled == false &&
		(\exists Integer senttask_localVar; TASKS.has(senttask_localVar); senttask.equals(senttask_localVar)) &&
		(\exists Integer receivedtask_localVar; TASKS.has(receivedtask_localVar); receivedtask.equals(receivedtask_localVar)) &&
		sendpriority.isEmpty() &&
		receivepriority.isEmpty() &&
		inv1 == true;*/
	public performance_limit_epriority(){
		tasks = new BSet<Integer>();
		senttasks = new BSet<Integer>();
		receivedtasks = new BSet<Integer>();
		send_task_executed = false;
		receive_task_executed = false;
		run_task_executed = false;
		send_task_enabled = false;
		receive_task_enabled = false;
		run_task_enabled = false;
		senttask = Utilities.someVal(TASKS);
		receivedtask = Utilities.someVal(TASKS);
		sendpriority = new BRelation<Integer,Integer>();
		receivepriority = new BRelation<Integer,Integer>();
		inv1 = true;

		events = new Thread[n_events];
		events[0] = new set_receivetask(this);
		events[1] = new receive_task(this);
		events[2] = new set_sendtask(this);
		events[3] = new send_task(this);
		events[4] = new run_task(this);

		for (int i = 0; i < n_events;i++){
			events[i].start();
		}
	}
}