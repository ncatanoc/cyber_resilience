package performance_limit_epriority_multi_threaded; 

import eventb_prelude.*;
import Util.Utilities;

public class receive_task extends Thread{
	/*@ spec_public */ private performance_limit_epriority machine; // reference to the machine 

	/*@ public normal_behavior
		requires true;
		assignable \everything;
		ensures this.machine == m; */
	public receive_task(performance_limit_epriority m) {
		this.machine = m;
	}

	/*@ public normal_behavior
		requires true;
 		assignable \nothing;
		ensures \result <==> (machine.get_receive_task_enabled().equals(true) && NAT.instance.has(p)); */
	public /*@ pure */ boolean guard_receive_task( Integer p) {
		return (machine.get_receive_task_enabled().equals(true) && NAT.instance.has(p));
	}

	/*@ public normal_behavior
		requires guard_receive_task(p);
		assignable machine.senttasks, machine.receivedtasks, machine.tasks, machine.sendpriority, machine.receivepriority, machine.receive_task_enabled, machine.send_task_executed, machine.receive_task_executed, machine.run_task_executed;
		ensures guard_receive_task(p) &&  machine.get_senttasks().equals(\old(machine.get_senttasks().difference(new BSet<Integer>(machine.get_receivedtask())))) &&  machine.get_receivedtasks().equals(\old((machine.get_receivedtasks().union(new BSet<Integer>(machine.get_receivedtask()))))) &&  machine.get_tasks().equals(\old((machine.get_tasks().union(new BSet<Integer>(machine.get_receivedtask()))))) &&  machine.get_sendpriority().equals(\old(machine.get_sendpriority().domainSubtraction(new BSet<Integer>(machine.get_receivedtask())))) &&  machine.get_receivepriority().equals(\old((machine.get_receivepriority().override(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(machine.get_receivedtask(),p)))))) &&  machine.get_receive_task_enabled() == \old(false) &&  machine.get_send_task_executed() == \old(false) &&  machine.get_receive_task_executed() == \old(true) &&  machine.get_run_task_executed() == \old(false); 
	 also
		requires !guard_receive_task(p);
		assignable \nothing;
		ensures true; */
	public void run_receive_task( Integer p){
		if(guard_receive_task(p)) {
			BSet<Integer> senttasks_tmp = machine.get_senttasks();
			BSet<Integer> receivedtasks_tmp = machine.get_receivedtasks();
			BSet<Integer> tasks_tmp = machine.get_tasks();
			BRelation<Integer,Integer> sendpriority_tmp = machine.get_sendpriority();
			BRelation<Integer,Integer> receivepriority_tmp = machine.get_receivepriority();
			Boolean receive_task_enabled_tmp = machine.get_receive_task_enabled();
			Boolean send_task_executed_tmp = machine.get_send_task_executed();
			Boolean receive_task_executed_tmp = machine.get_receive_task_executed();
			Boolean run_task_executed_tmp = machine.get_run_task_executed();

			machine.set_senttasks(senttasks_tmp.difference(new BSet<Integer>(machine.get_receivedtask())));
			machine.set_receivedtasks((receivedtasks_tmp.union(new BSet<Integer>(machine.get_receivedtask()))));
			machine.set_tasks((tasks_tmp.union(new BSet<Integer>(machine.get_receivedtask()))));
			machine.set_sendpriority(sendpriority_tmp.domainSubtraction(new BSet<Integer>(machine.get_receivedtask())));
			machine.set_receivepriority((receivepriority_tmp.override(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(machine.get_receivedtask(),p)))));
			machine.set_receive_task_enabled(false);
			machine.set_send_task_executed(false);
			machine.set_receive_task_executed(true);
			machine.set_run_task_executed(false);

			System.out.println("receive_task executed p: " + p + " ");
		}
	}

	public void run() {
		while(true) {
			Integer p = Utilities.someVal(new BSet<Integer>((new Enumerated(1,Utilities.max_integer))));
			machine.lock.lock(); // start of critical section
			run_receive_task(p);
			machine.lock.unlock(); // end of critical section
		}
	}
}
