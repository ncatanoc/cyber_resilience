package performance_limit_epriority_multi_threaded; 

import eventb_prelude.*;
import Util.Utilities;

public class run_task extends Thread{
	/*@ spec_public */ private performance_limit_epriority machine; // reference to the machine 

	/*@ public normal_behavior
		requires true;
		assignable \everything;
		ensures this.machine == m; */
	public run_task(performance_limit_epriority m) {
		this.machine = m;
	}

	/*@ public normal_behavior
		requires true;
 		assignable \nothing;
		ensures \result <==> (machine.get_receivedtasks().has(t) && m.equals(machine.get_receivepriority().range().max()) && machine.get_receivepriority().inverse().image(new BSet<Integer>(m)).has(t)); */
	public /*@ pure */ boolean guard_run_task( Integer m, Integer t) {
		return (machine.get_receivedtasks().has(t) && m.equals(machine.get_receivepriority().range().max()) && machine.get_receivepriority().inverse().image(new BSet<Integer>(m)).has(t));
	}

	/*@ public normal_behavior
		requires guard_run_task(m,t);
		assignable machine.receivedtasks, machine.senttasks, machine.tasks, machine.receivepriority, machine.sendpriority, machine.send_task_executed, machine.receive_task_executed, machine.run_task_executed;
		ensures guard_run_task(m,t) &&  machine.get_receivedtasks().equals(\old(machine.get_receivedtasks().difference(new BSet<Integer>(t)))) &&  machine.get_senttasks().equals(\old(machine.get_senttasks().difference(new BSet<Integer>(t)))) &&  machine.get_tasks().equals(\old(machine.get_tasks().difference(new BSet<Integer>(t)))) &&  machine.get_receivepriority().equals(\old(machine.get_receivepriority().domainSubtraction(new BSet<Integer>(t)))) &&  machine.get_sendpriority().equals(\old(machine.get_sendpriority().domainSubtraction(new BSet<Integer>(t)))) &&  machine.get_send_task_executed() == \old(false) &&  machine.get_receive_task_executed() == \old(false) &&  machine.get_run_task_executed() == \old(true); 
	 also
		requires !guard_run_task(m,t);
		assignable \nothing;
		ensures true; */
	public void run_run_task( Integer m, Integer t){
		if(guard_run_task(m,t)) {
			BSet<Integer> receivedtasks_tmp = machine.get_receivedtasks();
			BSet<Integer> senttasks_tmp = machine.get_senttasks();
			BSet<Integer> tasks_tmp = machine.get_tasks();
			BRelation<Integer,Integer> receivepriority_tmp = machine.get_receivepriority();
			BRelation<Integer,Integer> sendpriority_tmp = machine.get_sendpriority();
			Boolean send_task_executed_tmp = machine.get_send_task_executed();
			Boolean receive_task_executed_tmp = machine.get_receive_task_executed();
			Boolean run_task_executed_tmp = machine.get_run_task_executed();

			machine.set_receivedtasks(receivedtasks_tmp.difference(new BSet<Integer>(t)));
			machine.set_senttasks(senttasks_tmp.difference(new BSet<Integer>(t)));
			machine.set_tasks(tasks_tmp.difference(new BSet<Integer>(t)));
			machine.set_receivepriority(receivepriority_tmp.domainSubtraction(new BSet<Integer>(t)));
			machine.set_sendpriority(sendpriority_tmp.domainSubtraction(new BSet<Integer>(t)));
			machine.set_send_task_executed(false);
			machine.set_receive_task_executed(false);
			machine.set_run_task_executed(true);

			System.out.println("run_task executed m: " + m + " t: " + t + " ");
		}
	}

	public void run() {
		while(true) {
			Integer m = Utilities.someVal(new BSet<Integer>((new Enumerated(1,Utilities.max_integer))));
			Integer t = Utilities.someVal(new BSet<Integer>((new Enumerated(1,Utilities.max_integer))));
			machine.lock.lock(); // start of critical section
			run_run_task(m,t);
			machine.lock.unlock(); // end of critical section
		}
	}
}
