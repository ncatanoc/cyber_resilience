package performance_limit_epriority_multi_threaded; 

import eventb_prelude.*;
import Util.Utilities;

public class set_receivetask extends Thread{
	/*@ spec_public */ private performance_limit_epriority machine; // reference to the machine 

	/*@ public normal_behavior
		requires true;
		assignable \everything;
		ensures this.machine == m; */
	public set_receivetask(performance_limit_epriority m) {
		this.machine = m;
	}

	/*@ public normal_behavior
		requires true;
 		assignable \nothing;
		ensures (\result <==> (!machine.get_senttasks().equals(BSet.EMPTY) && !machine.get_sendpriority().equals(BSet.EMPTY))) && (\exists Integer tmp_receivedtask; machine.senttasks.has(tmp_receivedtask) && machine.sendpriority.inverse().image(new BSet<Integer>(machine.sendpriority.range().max())).has(tmp_receivedtask); machine.receivedtask.equals(tmp_receivedtask)); */
	public /*@ pure */ boolean guard_set_receivetask() {
		return (!machine.get_senttasks().equals(BSet.EMPTY) && !machine.get_sendpriority().equals(BSet.EMPTY));
	}

	/*@ public normal_behavior
		requires guard_set_receivetask();
		assignable machine.receivedtask, machine.receive_task_enabled;
		ensures guard_set_receivetask() && (\exists Integer tmp_receivedtask; machine.get_senttasks().has(tmp_receivedtask) && machine.get_sendpriority().inverse().image(new BSet<Integer>(machine.get_sendpriority().range().max())).has(tmp_receivedtask); machine.get_receivedtask().equals(tmp_receivedtask)) &&  machine.get_receive_task_enabled() == \old(true); 
	 also
		requires !guard_set_receivetask();
		assignable \nothing;
		ensures true; */
	public void run_set_receivetask(){
		if(guard_set_receivetask()) {
			Integer receivedtask_tmp = machine.get_receivedtask();
			Boolean receive_task_enabled_tmp = machine.get_receive_task_enabled();

		//machine.receivedtask = Utilities.non_det_assignment(receivedtask_tmp,(machine.get_senttasks().has(receivedtask_tmp) && machine.get_sendpriority().inverse().image(new BSet<Integer>(machine.get_sendpriority().range().max())).has(receivedtask_tmp)));
			machine.set_receive_task_enabled(true);

			System.out.println("set_receivetask executed ");
		}
	}

	public void run() {
		while(true) {
			machine.lock.lock(); // start of critical section
			run_set_receivetask();
			machine.lock.unlock(); // end of critical section
		}
	}
}
