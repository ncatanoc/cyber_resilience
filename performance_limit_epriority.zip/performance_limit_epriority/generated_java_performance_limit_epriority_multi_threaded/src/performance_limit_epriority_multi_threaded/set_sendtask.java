package performance_limit_epriority_multi_threaded; 

import eventb_prelude.*;
import Util.Utilities;

public class set_sendtask extends Thread{
	/*@ spec_public */ private performance_limit_epriority machine; // reference to the machine 

	/*@ public normal_behavior
		requires true;
		assignable \everything;
		ensures this.machine == m; */
	public set_sendtask(performance_limit_epriority m) {
		this.machine = m;
	}

	/*@ public normal_behavior
		requires true;
 		assignable \nothing;
		ensures \result <==> (!machine.TASKS.difference(machine.get_tasks()).equals(BSet.EMPTY) && NAT.instance.has(p)); */
	public /*@ pure */ boolean guard_set_sendtask( Integer p) {
		return (!machine.TASKS.difference(machine.get_tasks()).equals(BSet.EMPTY) && NAT.instance.has(p));
	}

	/*@ public normal_behavior
		requires guard_set_sendtask(p);
		assignable machine.senttask, machine.send_task_enabled;
		ensures guard_set_sendtask(p) && (\exists Integer senttask_localVar; machine.TASKS.difference(machine.get_tasks()).has(senttask_localVar); machine.get_senttask().equals(senttask_localVar)) &&  machine.get_send_task_enabled() == \old(true); 
	 also
		requires !guard_set_sendtask(p);
		assignable \nothing;
		ensures true; */
	public void run_set_sendtask( Integer p){
		if(guard_set_sendtask(p)) {
			Integer senttask_tmp = machine.get_senttask();
			Boolean send_task_enabled_tmp = machine.get_send_task_enabled();

		machine.set_senttask(Utilities.someVal(machine.TASKS.difference(machine.tasks)));
			machine.set_send_task_enabled(true);

			System.out.println("set_sendtask executed p: " + p + " ");
		}
	}

	public void run() {
		while(true) {
			Integer p = Utilities.someVal(new BSet<Integer>((new Enumerated(1,Utilities.max_integer))));
			machine.lock.lock(); // start of critical section
			run_set_sendtask(p);
			machine.lock.unlock(); // end of critical section
		}
	}
}
